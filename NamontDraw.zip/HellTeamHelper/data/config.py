# - *- coding: utf- 8 - *-
import configparser
#t.me/END_SOFT
config = configparser.ConfigParser()
config.read("settings.ini")
#t.me/END_SOFT
BOT_TOKEN = config["settings"]["token"]
admins = config["settings"]["admin_id"]
path_to_db = config["settings"]["path_to_db"]
admin_username = config["settings"]["admin_username"]
admin_link = config["settings"]["admin_link"]
#t.me/END_SOFT
if "," in admins:
    admins = admins.split(",")
else:
    if len(admins) >= 1:
        admins = [admins]
    else:
        admins = []
        print("Вы не указали админ ID.")
