# - *- coding: utf- 8 - *-
import logging

import asyncio

from aiogram import *
from aiogram.types import Update, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.utils.exceptions import (Unauthorized, InvalidQueryID, TelegramAPIError, UserDeactivated,
                                      CantDemoteChatCreator, MessageNotModified, MessageToDeleteNotFound, MessageTextIsEmpty,
                                      RetryAfter, CantParseEntities, MessageCantBeDeleted, TerminatedByOtherGetUpdates,
                                      CantGetUpdates, BotBlocked, ChatNotFound, ValidationError,
                                      Throttled, MessageToForwardNotFound, MessageIdInvalid, MessageToPinNotFound,
                                      MessageIdentifierNotSpecified, MessageCantBeEdited, MessageToEditNotFound, MessageToReplyNotFound,
                                      ToMuchMessages, PollsCantBeSentToPrivateChats, ButtonURLInvalid, URLHostIsEmpty,
                                      ButtonDataInvalid, FileIsTooBig, WrongFileIdentifier, GroupDeactivated,
                                      WebhookRequireHTTPS, BadWebhookPort, BadWebhookAddrInfo, BadWebhookNoAddressAssociatedWithHostname,
                                      MethodNotKnown, PhotoAsInputFileRequired, CantParseUrl, BotKicked,
                                      NetworkError, MigrateToChat, RestartingTelegram, TimeoutWarning,
                                      MessageCantBeForwarded, BadRequest)

from loader import dp

from data.config import *

@dp.errors_handler()
async def errors_handler(update, exception):

    # ———|  | ——— #

    # ———| CantParseEntities | ——— #
    if isinstance(exception, CantParseEntities):
        logging.exception(f"CantParseEntities: {exception} \nUpdate: {update}")
        return True

    # ———| TelegramAPIError | ——— #
    if isinstance(exception, TelegramAPIError):
        logging.exception(f"TelegramAPIError: {exception} \nUpdate: {update}")
        return True

    # ———| ChatNotFound | ——— #
    if isinstance(exception, ChatNotFound):
        logging.exception(f"ChatNotFound: {exception} \n Update: {update}")
        return True

    # ———| CantDemoteChatCreator | ——— #
    if isinstance(exception, CantDemoteChatCreator):
        logging.exception(f"CantDemoteChatCreator: {exception} \nUpdate: {update}")
        return True

    # ———| MessageNotModified | ——— #
    if isinstance(exception, MessageNotModified):
        logging.exception(f"MessageNotModified: {exception} \nUpdate: {update}")
        return True

    # ———| MessageCantBeDeleted | ——— #
    if isinstance(exception, MessageCantBeDeleted):
        logging.exception(f"MessageCantBeDeleted: {exception} \nUpdate: {update}")
        return True

    # ———| MessageToDeleteNotFound | ——— #
    if isinstance(exception, MessageToDeleteNotFound):
        logging.exception(f"MessageToDeleteNotFound: {exception} \nUpdate: {update}")
        return True

    # ———| MessageTextIsEmpty | ——— #
    if isinstance(exception, MessageTextIsEmpty):
        logging.exception(f"MessageTextIsEmpty: {exception} \nUpdate: {update}")
        return True

    # ———| UserDeactivated | ——— #
    if isinstance(exception, UserDeactivated):
        logging.exception(f"UserDeactivated: {exception} \nUpdate: {update}")
        return True

    # ———| InvalidQueryID | ——— #
    if isinstance(exception, InvalidQueryID):
        logging.exception(f"RetryAfter: {exception} \nUpdate: {update}")
        return True

    # ———| RetryAfter | ——— #
    if isinstance(exception, RetryAfter):
        logging.exception(f"RetryAfter: {exception} \nUpdate: {update}")
        return True

    # ———| Unauthorized | ——— #
    if isinstance(exception, Unauthorized):
        logging.exception(f"RetryAfter: {exception} \nUpdate: {update}")
        return True

    # ———| BotBlocked | ——— #
    if isinstance(exception, BotBlocked):
        logging.exception(f"BotBlocked: {exception} \nUpdate: {update}")
        return True

    # ———| TerminatedByOtherGetUpdates | ——— #
    if isinstance(exception, TerminatedByOtherGetUpdates):
        logging.exception(f"TerminatedByOtherGetUpdates: {exception} \nUpdate: {update}")
        return True

    # ———| CantGetUpdates | ——— #
    if isinstance(exception, CantGetUpdates):
        logging.exception(f"CantGetUpdates: {exception} \nUpdate: {update}")
        return True

    # ———| ValidationError | ——— #
    if isinstance(exception, ValidationError):
        logging.exception(f"ValidationError: {exception} \nUpdate: {update}")
        return True

    # ———| Throttled | ——— #
    if isinstance(exception, Throttled):
        logging.exception(f"Throttled: {exception} \nUpdate: {update}")
        return True

    # ———| MessageToForwardNotFound | ——— #
    if isinstance(exception, MessageToForwardNotFound):
        logging.exception(f"MessageToForwardNotFound: {exception} \nUpdate: {update}")
        return True

    # ———| MessageIdInvalid | ——— #
    if isinstance(exception, MessageIdInvalid):
        logging.exception(f"MessageIdInvalid: {exception} \nUpdate: {update}")
        return True

    # ———| MessageToPinNotFound | ——— #
    if isinstance(exception, MessageToPinNotFound):
        logging.exception(f"MessageToPinNotFound: {exception} \nUpdate: {update}")
        return True

    # ———| MessageIdentifierNotSpecified | ——— #
    if isinstance(exception, MessageIdentifierNotSpecified):
        logging.exception(f"MessageIdentifierNotSpecified: {exception} \nUpdate: {update}")
        return True

    # ———| MessageCantBeEdited | ——— #
    if isinstance(exception, MessageCantBeEdited):
        logging.exception(f"MessageCantBeEdited: {exception} \nUpdate: {update}")
        return True

    # ———| MessageCantBeForwarded | ——— #
    if isinstance(exception, MessageCantBeForwarded):
        logging.exception(f"MessageCantBeForwarded: {exception} \nUpdate: {update}")
        return True

    # ———| MessageToEditNotFound | ——— #
    if isinstance(exception, MessageToEditNotFound):
        logging.exception(f"MessageToEditNotFound: {exception} \nUpdate: {update}")
        return True

    # ———| ToMuchMessages | ——— #
    if isinstance(exception, ToMuchMessages):
        logging.exception(f"ToMuchMessages: {exception} \nUpdate: {update}")
        return True

    # ———| MessageToReplyNotFound | ——— #
    if isinstance(exception, MessageToReplyNotFound):
        logging.exception(f"MessageToReplyNotFound: {exception} \nUpdate: {update}")
        return True

    # ———| PollsCantBeSentToPrivateChats | ——— #
    if isinstance(exception, PollsCantBeSentToPrivateChats):
        logging.exception(f"PollsCantBeSentToPrivateChats: {exception} \nUpdate: {update}")
        return True

    # ———| ButtonURLInvalid | ——— #
    if isinstance(exception, ButtonURLInvalid):
        logging.exception(f"ButtonURLInvalid: {exception} \nUpdate: {update}")
        return True

    # ———| URLHostIsEmpty | ——— #
    if isinstance(exception, URLHostIsEmpty):
        logging.exception(f"URLHostIsEmpty: {exception} \nUpdate: {update}")
        return True

    # ———| ButtonDataInvalid | ——— #
    if isinstance(exception, ButtonDataInvalid):
        logging.exception(f"ButtonDataInvalid: {exception} \nUpdate: {update}")
        return True

    # ———| FileIsTooBig | ——— #
    if isinstance(exception, FileIsTooBig):
        logging.exception(f"FileIsTooBig: {exception} \nUpdate: {update}")
        return True

    # ———| WrongFileIdentifier | ——— #
    if isinstance(exception, WrongFileIdentifier):
        logging.exception(f"WrongFileIdentifier: {exception} \nUpdate: {update}")
        return True

    # ———| GroupDeactivated | ——— #
    if isinstance(exception, GroupDeactivated):
        logging.exception(f"GroupDeactivated: {exception} \nUpdate: {update}")
        return True

    # ———| WebhookRequireHTTPS | ——— #
    if isinstance(exception, WebhookRequireHTTPS):
        logging.exception(f"WebhookRequireHTTPS: {exception} \nUpdate: {update}")
        return True

    # ———| BadWebhookPort | ——— #
    if isinstance(exception, BadWebhookPort):
        logging.exception(f"BadWebhookPort: {exception} \nUpdate: {update}")
        return True

    # ———| BadWebhookAddrInfo | ——— #
    if isinstance(exception, BadWebhookAddrInfo):
        logging.exception(f"BadWebhookAddrInfo: {exception} \nUpdate: {update}")
        return True

    # ———| BadWebhookNoAddressAssociatedWithHostname | ——— #
    if isinstance(exception, BadWebhookNoAddressAssociatedWithHostname):
        logging.exception(f"BadWebhookNoAddressAssociatedWithHostname: {exception} \nUpdate: {update}")
        return True

    # ———| MethodNotKnown | ——— #
    if isinstance(exception, MethodNotKnown):
        logging.exception(f"MethodNotKnown: {exception} \nUpdate: {update}")
        return True

    # ———| PhotoAsInputFileRequired | ——— #
    if isinstance(exception, PhotoAsInputFileRequired):
        logging.exception(f"PhotoAsInputFileRequired: {exception} \nUpdate: {update}")
        return True

    # ———| CantParseUrl | ——— #
    if isinstance(exception, CantParseUrl):
        logging.exception(f"CantParseUrl: {exception} \nUpdate: {update}")
        return True

    # ———| BotKicked | ——— #
    if isinstance(exception, BotKicked):
        logging.exception(f"BotKicked: {exception} \nUpdate: {update}")
        return True

    # ———| NetworkError | ——— #
    if isinstance(exception, NetworkError):
        logging.exception(f"NetworkError: {exception} \nUpdate: {update}")
        return True

    # ———| MigrateToChat | ——— #
    if isinstance(exception, MigrateToChat):
        logging.exception(f"MigrateToChat: {exception} \nUpdate: {update}")
        return True

    # ———| RestartingTelegram | ——— #
    if isinstance(exception, RestartingTelegram):
        logging.exception(f"RestartingTelegram: {exception} \nUpdate: {update}")
        return True

    # ———| TimeoutWarning | ——— #
    if isinstance(exception, TimeoutWarning):
        logging.exception(f"TimeoutWarning: {exception} \nUpdate: {update}")
        return True

    # ———| BadRequest | ——— #
    if isinstance(exception, BadRequest):
        logging.exception(f"BadRequest: {exception} \nUpdate: {update}")
        return True

    logging.exception(f"Update: {update} \n{exception}")