# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

import asyncio

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from states.state_functions import *
from utils.other_func import clear_firstname

import json
import requests

from time import sleep
from datetime import datetime, date, timedelta

from handlers.users.user_functions import count_generations

# Фейк личность
@dp.callback_query_handler(lambda c: c. data=='fake_person')
async def fake_person(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        'Выберите национальность фейка.',
        reply_markup=FAKE_PERSON_CHOISE_MENU())

# ◀️ Назад
@dp.callback_query_handler(lambda c: c. data=='go_back_to_fake_person_choise_menu_from_fake_person')
async def go_back_to_fake_person_choise_menu_from_fake_person(callback_query: types.CallbackQuery):
	await callback_query.message.edit_text(
        'Выберите национальность фейка.',
        reply_markup=FAKE_PERSON_CHOISE_MENU())

# 🇺🇦
@dp.callback_query_handler(lambda c: c. data=='fake_person_ua')
async def fake_person_ua(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/ukrainian-ukraine")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇷🇺
@dp.callback_query_handler(lambda c: c. data=='fake_person_ru')
async def fake_person_ru(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/russian-russia")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇰🇿
@dp.callback_query_handler(lambda c: c. data=='fake_person_kz')
async def fake_person_kz(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/kazakh-kazakhstan")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇵🇱
@dp.callback_query_handler(lambda c: c. data=='fake_person_pl')
async def fake_person_pl(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/polish-poland")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇨🇿
@dp.callback_query_handler(lambda c: c. data=='fake_person_cz')
async def fake_person_cz(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/czech-czech-republic")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇩🇪
@dp.callback_query_handler(lambda c: c. data=='fake_person_de')
async def fake_person_de(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/german_germany")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇮🇹
@dp.callback_query_handler(lambda c: c. data=='fake_person_it')
async def fake_person_it(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/italian-italy")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇪🇸
@dp.callback_query_handler(lambda c: c. data=='fake_person_sp')
async def fake_person_sp(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/spanish-spain")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇺🇸
@dp.callback_query_handler(lambda c: c. data=='fake_person_us')
async def fake_person_us(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/english-united-states")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇫🇷
@dp.callback_query_handler(lambda c: c. data=='fake_person_fr')
async def fake_person_fr(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/french-france")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇸🇪
@dp.callback_query_handler(lambda c: c. data=='fake_person_se')
async def fake_person_se(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/swedish-sweden")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇫🇮
@dp.callback_query_handler(lambda c: c. data=='fake_person_fi')
async def fake_person_fi(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/finnish-finland")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇬🇧
@dp.callback_query_handler(lambda c: c. data=='fake_person_uk')
async def fake_person_uk(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/english-united-kingdom")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇯🇵
@dp.callback_query_handler(lambda c: c. data=='fake_person_jp')
async def fake_person_jp(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/japanese-japan")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇳🇱
@dp.callback_query_handler(lambda c: c. data=='fake_person_nl')
async def fake_person_nl(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/dutch-netherlands")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇩🇰
@dp.callback_query_handler(lambda c: c. data=='fake_person_dk')
async def fake_person_dk(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/danish-denmark")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇯🇴
@dp.callback_query_handler(lambda c: c. data=='fake_person_jo')
async def fake_person_jo(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/arabic-jordan")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇱🇻
@dp.callback_query_handler(lambda c: c. data=='fake_person_lv')
async def fake_person_lv(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/latvian-latvia")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇲🇩
@dp.callback_query_handler(lambda c: c. data=='fake_person_md')
async def fake_person_md(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/romanian-moldova")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)

# 🇨🇳
@dp.callback_query_handler(lambda c: c. data=='fake_person_cn')
async def fake_person_cn(callback_query: types.CallbackQuery):
	try:
		r = requests.get("https://api.namefake.com/chinese-china")
		data = json.loads(r.text)

		fake_name = str(data['name'])
		fake_maiden_name = str(data['maiden_name'])
		fake_birth_date = str(data['birth_data'])
		fake_height = str(data['height'])
		fake_weight = str(data['weight'])
		fake_blood = str(data['blood'])
		fake_first_phone = str(data['phone_h'])
		fake_second_phone = str(data['phone_w'])
		fake_email1 = str(data['email_u'])
		fake_email2 = str(data['email_d'])
		fake_username = str(data['username'])
		fake_password = str(data['password'])
		fake_ipv4 = str(data['ipv4'])
		fake_mac_adress = str(data['macaddress'])
		fake_plasticcard = str(data['plasticcard'])

		await callback_query.message.edit_text(
			text=f'''
<b>🎭 Фейк личность.</b>
├<b>ФИО </b><code>{fake_name}</code>
├<b>Девичья фамилия: </b><code>{fake_maiden_name}</code>
├<b>Дата рождения: </b><code>{fake_birth_date}</code>
├<b>Рост: </b><code>{fake_height}</code>
├<b>Вес: </b><code>{fake_weight}</code>
├<b>Тип крови: </b><code>{fake_blood}</code>
├<b>Первый телефон: </b><code>{fake_first_phone}</code>
├<b>Второй телефон: </b><code>{fake_second_phone}</code>
├<b>Эл. почта: </b><code>{fake_email1}{fake_email2}</code>
├<b>Имя пользователя: </b><code>{fake_username}</code>
├<b>Пароль: </b><code>{fake_password}</code>
├<b>IPV4: </b><code>{fake_ipv4}</code>
├<b>MAC-адрес: </b><code>{fake_mac_adress}</code>
└<b>Пластиковая карта: </b><code>{fake_plasticcard}</code>
			''',
			reply_markup=GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON())
		count_generations(callback_query.message.chat.id, 1)
	except Exception as e:
		print(e)