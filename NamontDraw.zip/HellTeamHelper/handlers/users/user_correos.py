# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# ◀️ Назад (в 🇪🇸 Correos)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_correos_menu')
async def go_back_to_correos_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇪🇸 Correos.', reply_markup=CORREOS_MENU())

# 🇪🇸 Correos
@dp.callback_query_handler(lambda c: c.data=='correos')
async def correos(callback_query: types.CallbackQuery):
    try:
        await callback_query.message.edit_text('🇪🇸 Correos.', reply_markup=CORREOS_MENU())
    except Exception as e:
        print(e)

# 🇪🇸 Доставка 2.0
@dp.callback_query_handler(lambda c: c. data=='correos_delivery')
async def correos_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/Ev8rGlu',
            caption='🇪🇸 Доставка 2.0.',
            reply_markup=GO_BACK_TO_CORREOS_MENU())
    except Exception as e:
        print(e)

# 🇪🇸 PUSH уведомление
@dp.callback_query_handler(lambda c: c. data=='correos_push')
async def correos_push(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/ChWMvim',
            caption='🇪🇸 PUSH уведомление.',
            reply_markup=GO_BACK_TO_CORREOS_MENU())
    except Exception as e:
        print(e)

# 🇪🇸 Пополнение
@dp.callback_query_handler(lambda c: c. data=='correos_replenishment')
async def correos_replenishment(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/ovPBUF5',
            caption='🇪🇸 Пополнение.',
            reply_markup=GO_BACK_TO_CORREOS_MENU())
    except Exception as e:
        print(e)

# 🇪🇸 Возврат
@dp.callback_query_handler(lambda c: c. data=='correos_return')
async def correos_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/OtmV96m',
            caption='🇪🇸 Возврат.',
            reply_markup=GO_BACK_TO_CORREOS_MENU())
    except Exception as e:
        print(e)