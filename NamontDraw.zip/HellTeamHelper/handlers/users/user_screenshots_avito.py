# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# SCREENSHOTS: 🇷🇺 Авито

# 🇷🇺Авито
@dp.callback_query_handler(lambda c: c. data=='avito_screenshots')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇷🇺 Авито', reply_markup=AVITO_MENU())

# ◀️ Назад (в 🇷🇺 Авито)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_avito_menu')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇷🇺 Авито', reply_markup=AVITO_MENU())

# 🇷🇺 2.0 — подозрительный домен
@dp.callback_query_handler(lambda c: c. data=='two_suspicious_domen')
async def callback_two_suspicious_domen(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/SqXRWRc',
            caption='🇷🇺 2.0 — подозрительный домен.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 2.0 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='two_email_inquiry')
async def callback_two_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/dYTgDUP')
        media.attach_photo('https://imgur.com/1AhKJFS')
        media.attach_photo('https://imgur.com/ETUbTKF')
        media.attach_photo('https://imgur.com/YXZHJHp')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 2.0 — запрос почты.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 3.0 Запрос кода
@dp.callback_query_handler(lambda c: c. data=='three_code_inquiry')
async def callback_three_code_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/9ConSwR',
            caption='🇷🇺 3.0 — запрос кода.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Cписание / баланс
@dp.callback_query_handler(lambda c: c. data=='write-off_or_balance')
async def callback_off_or_balance(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/n4vOvD0')
        media.attach_photo('https://imgur.com/GsgFJRM')
        media.attach_photo('https://imgur.com/E90JEq5')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 Cписание / баланс.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 CVC код
@dp.callback_query_handler(lambda c: c. data=='cvc_code')
async def callback_cvc_code(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/RFCZpqb',
            caption='🇷🇺 CVC код.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Нету уведомления
@dp.callback_query_handler(lambda c: c. data=='no_notification')
async def callback_no_notification(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/QfOOVBE')
        media.attach_photo('https://imgur.com/3IO3sOP')
        media.attach_photo('https://imgur.com/pAXpIu7')

        await bot.send_media_group(callback_query.message.chat.id, media=media)

        await callback_query.message.answer(
            '🇷🇺 Нету уведомления.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Авито — 900
@dp.callback_query_handler(lambda c: c. data=='error_900')
async def callback_error_900(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/pRE38HZ')
        media.attach_photo('https://imgur.com/ScuyDEg')

        await bot.send_media_group(callback_query.message.chat.id, media=media)

        await callback_query.message.answer(
            '🇷🇺 Авито — 900',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Доставка (ссылка)
@dp.callback_query_handler(lambda c: c. data=='delivery_link')
async def callback_delivery_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/OCFULMV')
        media.attach_photo('https://imgur.com/EtP4eNx')
        media.attach_photo('https://imgur.com/lwTcOvi')
        media.attach_photo('https://imgur.com/shDukiX')
        media.attach_photo('https://imgur.com/K2VypaK')
        media.attach_photo('https://imgur.com/zYvbBtP')
        media.attach_photo('https://imgur.com/mqWAwTK')
        media.attach_photo('https://imgur.com/T6YsP4Z')

        await bot.send_media_group(callback_query.message.chat.id, media=media)

        await callback_query.message.answer(
            '🇷🇺 Как работает доставка (ссылка).',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Доставка (SMS)
@dp.callback_query_handler(lambda c: c. data=='delivery_sms')
async def callback_delivery_sms(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/WipnQ7D',
            caption='🇷🇺 Как работает доставка (SMS).',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Доставка (Email)
@dp.callback_query_handler(lambda c: c. data=='delivery_email')
async def callback_delivery_email(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/ucxDj7K',
            caption='🇷🇺 Как работает доставка (Email).',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Email-инструкция
@dp.callback_query_handler(lambda c: c. data=='order_is_processed_email')
async def callback_order_is_processed_email(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/GW4bQq5',
            caption='🇷🇺 Заказ оформлен, продавец получит инструкцию на Email.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 По SMS / ссылке
@dp.callback_query_handler(lambda c: c. data=='sms_or_link')
async def callback_sms_or_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/rgfLhn1')
        media.attach_photo('https://imgur.com/I0ek5AW')

        await bot.send_media_group(callback_query.message.chat.id, media=media)

        await callback_query.message.answer(
            '🇷🇺 Заказ оформлен, продавец получит средства по SMS / ссылке.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Получение денег
@dp.callback_query_handler(lambda c: c. data=='money_receiving')
async def callback_money_receiving(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/PFnVWKk',
            caption='🇷🇺 Как происходит получение денег.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Возврат
@dp.callback_query_handler(lambda c: c. data=='money_return')
async def callback_money_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/upqg8oP',
            caption='🇷🇺 Возврат',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Получить по ссылке
@dp.callback_query_handler(lambda c: c. data=='get_by_link')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/SbDzjK1',
            caption='🇷🇺 Получить по ссылке.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Блокирует/не грузит
@dp.callback_query_handler(lambda c: c. data=='blocked_or_not_loading')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/ocBP51a',
            caption='🇷🇺 Не загружает или блокирует браузер.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Указан Связной
@dp.callback_query_handler(lambda c: c. data=='svyaznoi')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/uLUSGA2',
            caption='🇷🇺 В названии платежа указан Связной.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Указан RGS-Bank
@dp.callback_query_handler(lambda c: c. data=='rgs_bank')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/Acn8GAN',
            caption='🇷🇺 В названии платежа указан RGS-Bank.',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 SMS от Бaнкa
@dp.callback_query_handler(lambda c: c. data=='moneyback')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/eDV6APZ',
            caption='🇷🇺 Деньги возвращаются на карту после резервирования (SMS от бaнкa).',
            reply_markup=GO_BACK_TO_AVITO_MENU())
    except Exception as e:
        print(e)