# - *- coding: utf- 8 - *-
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from aiogram.utils.exceptions import MessageCantBeDeleted

from keyboards.default import *
from loader import dp, bot

from keyboards.inline.user_func import CLOSE_BTN

# Обработка всех колбэков которые потеряли стейты после перезапуска скрипта
@dp.callback_query_handler(text="...", state="*")
async def processing_missed_callback(call: CallbackQuery, state: FSMContext):
    await call.answer(cache_time=60)

# Обработка всех колбэков которые потеряли стейты после перезапуска скрипта
@dp.callback_query_handler(state="*")
async def processing_missed_callback(call: CallbackQuery, state: FSMContext):
    try:
        await bot.delete_message(call.message.chat.id, call.message.message_id)
    except MessageCantBeDeleted:
        pass
    await state.finish()
    
    await bot.delete_message(call.message.chat.id, call.message.message_id)
    await bot.delete_message(message.chat.id, message.message_id)
    
    await bot.send_message(
        call.from_user.id,
        "❌<b>Ошибка, перезапустите бота.</b>",
        reply_markup=check_user_out_func(call.from_user.id))