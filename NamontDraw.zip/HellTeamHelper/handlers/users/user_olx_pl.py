# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇵🇱 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='olx_poland_email_inquiry')
async def olx_poland_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/XU9EQ3d',
            caption='🇵🇱 Запрос почты.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)

# 🇵🇱 Нет баланса
@dp.callback_query_handler(lambda c: c. data=='olx_poland_no_balance')
async def olx_poland_no_balance(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/Wv9fLOR',
            caption='🇵🇱 Нет баланса.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)

# 🇵🇱 Доставка
@dp.callback_query_handler(lambda c: c. data=='olx_poland_delivery')
async def olx_poland_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/aSEcAcU')
        media.attach_photo('https://imgur.com/DxsSvO7')
        media.attach_photo('https://imgur.com/CMFImZY')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇵🇱 Как работает доставка.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)

# 🇵🇱 Лимит на карте
@dp.callback_query_handler(lambda c: c. data=='olx_poland_card_limit')
async def olx_poland_card_limit(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/N5k84k0',
            caption='🇵🇱 Лимит на карте.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)

# 🇵🇱 Сообщить ссылку
@dp.callback_query_handler(lambda c: c. data=='olx_poland_show_link')
async def olx_poland_show_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/hvcfdEK',
            caption='🇵🇱 Сообщить ссылку.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)

# 🇵🇱 Товар оплачен
@dp.callback_query_handler(lambda c: c. data=='olx_poland_item_paid')
async def olx_poland_item_paid(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/us4S75F',
            caption='🇵🇱 Товар оплачен.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)

# 🇵🇱 Нужно подтверждение
@dp.callback_query_handler(lambda c: c. data=='olx_poland_need_verify')
async def olx_poland_need_verify(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/r0vq1fF',
            caption='🇵🇱 Нужно подтверждение.',
            reply_markup=GO_BACK_TO_OLX_POLAND_MENU())
    except Exception as e:
        print(e)