# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# 🧾 Диалоги
@dp.callback_query_handler(lambda c: c. data=='helper_dialogs')
async def helper_dialogs(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🧾 Диалоги', reply_markup=DIALOGS_MENU())

# ◀️ Назад (в 🧾 Диалоги)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_dialogs_menu')
async def go_back_to_dialogs_menu(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🧾 Диалоги.', reply_markup=DIALOGS_MENU())

# "Приветствие"
@dp.callback_query_handler(lambda c: c. data=='dialogs_welcome')
async def dialogs_welcome(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(dialogs_welcome_text, reply_markup=GO_BACK_TO_DIALOGS_MENU())

# "🛍 Вопросы о товаре"
@dp.callback_query_handler(lambda c: c. data=='dialogs_question_about_delivery')
async def dialogs_question_about_delivery(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(dialogs_question_about_delivery_text, reply_markup=GO_BACK_TO_DIALOGS_MENU())

# "🚚 Сказать о доставке"
@dp.callback_query_handler(lambda c: c. data=='dialogs_tell_about_delivery')
async def dialogs_tell_about_delivery(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(dialogs_tell_about_delivery_text, reply_markup=GO_BACK_TO_DIALOGS_MENU())

# "❔Другие вопросы"
@dp.callback_query_handler(lambda c: c. data=='dialogs_other_questions')
async def dialogs_other_questions(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(dialogs_other_questions_text, reply_markup=GO_BACK_TO_DIALOGS_MENU())

# MESSAGES: DIALOGS
dialogs_welcome_text = '''
<b>Лучшее приветствие.</b> \n\n➖ Добрый день, пишу по поводу вашего объявления на ..., актуально ещё ?
'''
dialogs_question_about_delivery_text = '''
<b>Вопросы, которые следует задать мамонту о товаре.</b>

➖ В каком оно состоянии ?

➖ Когда покупали ?

➖ Есть какие - либо ньюансы ?

➖ Все ли рабочее ?

➖ Можете отправить доп. фото ?
'''
dialogs_tell_about_delivery_text = '''
<b>Лучший способ сказать о доставке.</b>

➖ Очень заинтересована в покупке, готов(а) приобрести, но я в ... , можно оплатить ... доставкой ?

После к вам приедет курьер по указанному вами адресу и вы ему отдадите «Название товара».
'''
dialogs_other_questions_text = '''
<b>Другие вопросы.</b>

➖ «Могу отправить наложкой ?»

На это мы отвечаем «Просто очень понравилась ваш «название товара», но, к сожалению всей семьей сидим на карантине, есть только один вариант, это курьер».

Тут они или соглашаются на куфар доставку, или отвечают нет.
'''