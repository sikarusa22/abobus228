# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

import asyncio

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from states.state_functions import *
from utils.other_func import clear_firstname

# 🗑 Закрыть
@dp.callback_query_handler(lambda c: c. data=='close_btn', state="*")
async def close_btn(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

# Финиш состояния и редактирование текста с добавлением меню инструментов
@dp.callback_query_handler(lambda c: c. data=='close_nazad_btn', state="*")
async def close_nazad_btn(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text=f"<b>🛠 Инструменты</b>",
        reply_markup=INSTRUMENTS_MENU())

# 🌌 Cкриншоты
@dp.callback_query_handler(lambda c: c. data=='helper_screens', state="*")
async def helper_screens(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text="🌌 Cкриншоты",
        reply_markup=SCREENSHOTS_MENU())

# ◀️ Назад (в 🌌 Cкриншоты)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_screenshots_menu', state="*")
async def go_back_to_screenshots_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text('🌌 Cкриншоты', reply_markup=SCREENSHOTS_MENU())

# ◀️ Назад (в 🛠 Инструменты)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_instruments_menu', state="*")
async def go_back_to_instruments_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text=f"<b>🛠 Инструменты</b>",
        reply_markup=INSTRUMENTS_MENU())

# Отменить стейт, удалить сообщение и показать меню инструментов
@dp.callback_query_handler(lambda c: c. data=='cc_and_show_instruments_menu', state="*")
async def cc_and_show_instruments_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

# 🔍 Пробив меню
@dp.callback_query_handler(lambda c: c. data=='show_deanon_menu', state="*")
async def show_deanon_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text="<b>🔍 Пробив</b>",
        reply_markup=DEANON_MENU())

# 🔍 Пробив IP
@dp.callback_query_handler(lambda c: c. data=='ip_info', state="*")
async def ip_info(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text=f'''
<b>Отправьте IP-адрес, который хотите пробить.</b>

<code>Например: 90.148.111.111</code>
        ''',
        reply_markup=CLOSE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_deanon_ip.set()

# 🔍 Пробив телефона
@dp.callback_query_handler(lambda c: c. data=='phone_info', state="*")
async def phone_info(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text=f'''
<b>Отправьте телефон, который хотите пробить (вместе с кодом страны).</b>

<code>Например: +380961008811</code>
        ''',
        reply_markup=CLOSE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_deanon_phone.set()

# 💳 BIN чекер
@dp.callback_query_handler(lambda c: c. data=='bin_checker', state="*")
async def bin_checker(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text(
        text=f'''
<b>Отправьте BIN (первые 6 цифр карты) и бот выдаст результат.</b>

<code>Например: 460538</code>
        ''',
        reply_markup=CLOSE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_check_bin.set()
