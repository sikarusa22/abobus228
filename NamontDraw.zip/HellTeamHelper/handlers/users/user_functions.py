# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
import asyncio

from data.config import admins
from filters import IsPrivate
from subprocess import check_output
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from states.state_functions import *
from utils.other_func import clear_firstname

import json
import requests

from time import sleep
import sqlite3, os
from datetime import datetime, date, timedelta

# Пробив IP-адреса
@dp.message_handler(state=StorageFunctions.here_deanon_ip)
async def deanon_ip(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_deanon_ip.set()

        r = requests.get(f"https://api.ipdata.co/{message.text}?api-key=b3815070f14af5a71cd4a831e53f0f011cddc285ec0353431170586f")
        data = json.loads(r.text)

        continent_name = str(data['continent_name'])
        continent_code = str(data['continent_code'])
        time_zone = str(data['time_zone']['name'])
        country_name = str(data['country_name'])
        country_code = str(data['country_code'])
        city = str(data['city'])
        region = str(data['region'])
        latitude = str(data['latitude'])
        longitude = str(data['longitude'])
        postal = str(data['postal'])

        asn = str(data['asn']['asn'])
        provider = str(data['asn']['name'])
        provider_type = str(data['asn']['type'])
        provider_domen = str(data['asn']['domain'])

        calling_code = str(data['calling_code'])
        currency = str(data['currency']['name'])
        currency_code = str(data['currency']['code'])
        current_time = str(data['time_zone']['current_time'])

        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer(
        	text=f'''
<b>📨 Результаты поиска.</b>

<b>🌐 IP-адрес</b> — <code>{message.text}</code>
├<b>Континет: </b><code>{continent_name} ({continent_code})</code>
├<b>Часовой пояс: </b><code>{time_zone}</code>
├<b>Страна: </b><code>{country_name} ({country_code})</code>
├<b>Город: </b><code>{city} | {region}</code>
├<b>Координаты: </b><code>{latitude} | {longitude}</code>
└<b>Почтовый индекс: </b><code>{postal}</code>

<b>👨‍🔧 Провайдер</b>
├<b>ASN: </b><code>{asn}</code>
├<b>Провайдер: </b><code>{provider}</code>
├<b>Тип: </b><code>{provider_type}</code>
└<b>Домен: </b><code>{provider_domen}</code>

<b>🗂 Прочее</b>
├<b>Код страны: </b><code>+{calling_code}</code>
├<b>Валюта: </b><code>{currency} ({currency_code})</code>
└<b>Точное время: </b><code>{current_time}</code>
            ''',
        	reply_markup=CLOSE_BTN())

        await bot.send_location(
            message.chat.id,
            latitude=latitude,
            longitude=longitude)
        await state.finish()
        count_deanons(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('IP-адрес неверный, попробуйте еще раз.')
        print(e)

# Пробив телефона
@dp.message_handler(state=StorageFunctions.here_deanon_phone)
async def deanon_phone(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_deanon_phone.set()

        number = message.text

       	r = random.randint(1, 2)

        if r == 1:
            r = requests.get(f'https://phonevalidation.abstractapi.com/v1/?api_key=b92b00fee023493397b92868470d96d8&phone={number}')
        elif r == 2:
            r = requests.get(f'https://phonevalidation.abstractapi.com/v1/?api_key=183979e0820b4ffea3db189883da8666&phone={number}')

        data = json.loads(r.text)

        phone_country_name = str(data['country']['name'])
        phone_country_prefix = str(data['country']['prefix'])
        phone_country_code = str(data['country']['code'])
        phone_phone_type = str(data['type'])
        phone_carrier = str(data['carrier'])
        phone_phone_local = str(data['format']['local'])

        #await bot.delete_message(message.chat.id, message.message_id)

        url = f'https://api.whatsapp.com/send?phone={number}'
        url2 = f'https://botapi.co/viber/{number}'

        deanon_links = types.InlineKeyboardMarkup(row_width=2)
        deanon_links.add(
            types.InlineKeyboardButton(text='✅ WhatsApp', url=url),
            types.InlineKeyboardButton(text='📧 Viber', url=url2),
            types.InlineKeyboardButton(text='🗑 Закрыть', callback_data='close_btn')
        )

        await message.answer(
            f'''
<b>📨 Результаты поиска.</b>

<b>☎️ Телефон</b> — <code>{message.text}</code>
├<b>Локальный: </b><code>{phone_phone_local}</code>
├<b>Страна: </b> <code>{phone_country_name}</code>
├<b>Код страны: </b> <code>{phone_country_prefix}</code>
├<b>Префикс: </b> <code>{phone_country_code}</code>
├<b>Тип: </b><code>{phone_phone_type}</code>
└<b>Оператор: </b><code>{phone_carrier}</code>
           ''',
            reply_markup=deanon_links,
            disable_web_page_preview = True)
        await state.finish()
        count_deanons(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Телефон неверный, попробуйте еще раз.')
        print(e)

# 💳 BIN чекер
@dp.message_handler(state=StorageFunctions.here_check_bin)
async def check_bin(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_check_bin.set()

        r = requests.get(f"https://lookup.binlist.net/{message.text}")
        data = json.loads(r.text)

        card_scheme = str(data['scheme'])
        card_type = str(data['type'])
        card_country_emoji = str(data['country']['emoji'])
        card_country_name = str(data['country']['name'])
        card_country_currency = str(data['country']['currency'])
        card_bank_name = str(data['bank']['name'])

        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer(
            f'''
<b>Результаты по BIN: {message.text}.</b>
├<b>Сеть: </b><code>{card_scheme}</code>
├<b>Тип карты: </b><code>{card_type}</code>
├<b>Страна: </b><code>{card_country_emoji} {card_country_name}</code>
├<b>Валюта: </b><code>{card_country_currency}</code>
└<b>Банк: </b><code>{card_bank_name}</code>
            ''',
            reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
        await state.finish()
        count_deanons(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('BIN карты неверный, попробуйте еще раз.')
        print(e)

# 🔗 Сократить ссылку (01)
@dp.callback_query_handler(lambda c: c. data=='short_url')
async def short_url(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        '''
<b>Отправьте ссылку для сокращения.</b>

Ссылка должна начинатся с <code>https://</code>
        ''',
        reply_markup=CLOSE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_short_link.set()

# 🔗 Сократить ссылку (02)
@dp.message_handler(state=StorageFunctions.here_short_link)
async def short_link(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_short_link.set()

        url = f"https://uni.su/api/?url={message.text}"
        url2 = f"https://is.gd/create.php?format=simple&url={message.text}"
        url3 = f"https://v.gd/create.php?format=simple&url={message.text}"

        r1 = requests.get(url)
        r2 = requests.get(url2)
        r3 = requests.get(url3)

        url_1 = r1.text
        url_2 = r2.text
        url_3 = r3.text

        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer(
            f'''
<b>Сокращенные ссылки.</b>

{url_1}
{url_2}
{url_3}
            ''',
            disable_web_page_preview = True,
            reply_markup=GO_BACK_TO_INSTRUMENTS_MENU())
        await state.finish()
        count_shorts(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🌌 Скриншот сайта (01)
@dp.callback_query_handler(lambda c: c. data=='make_site_screenshot')
async def make_site_screenshot(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        '''
<b>Отправьте ссылку на сайт.</b>

Ссылка должна начинаться с <code>https://</code>
        ''',
        reply_markup=CLOSE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_make_screen.set()

# 🌌 Скриншот сайта (02)
@dp.message_handler(state=StorageFunctions.here_make_screen)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_make_screen.set()

        user_link = str(message.text)
        r_ul = requests.get(f"https://webshot.deam.io/{user_link}/?width=1440&height=1024?type=png")

        await bot.delete_message(message.chat.id, message.message_id)
        await bot.send_photo(
            message.chat.id,
            photo=r_ul.content,
            caption=f'Скриншот с сайта {user_link}.',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_screens(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

######### СЧЁТ ПРОБИВОВ #########
def count_deanons(user_id, value):
    conn = sqlite3.connect('data/botBD.sqlite')
    cursor = conn.cursor()
    cursor.execute(f'UPDATE storage_users SET deanons = deanons + {value} WHERE user_id = "{user_id}"')
    conn.commit()

######### СЧЁТ ВСЕХ ГЕНЕРАЦИЙ #########
def count_generations(user_id, value):
    conn = sqlite3.connect('data/botBD.sqlite')
    cursor = conn.cursor()
    cursor.execute(f'UPDATE storage_users SET generations = generations + {value} WHERE user_id = "{user_id}"')
    conn.commit()

######### СЧЁТ СОКРАЩЕННЫХ ССЫЛОК #########
def count_shorts(user_id, value):
    conn = sqlite3.connect('data/botBD.sqlite')
    cursor = conn.cursor()
    cursor.execute(f'UPDATE storage_users SET shorts = shorts + {value} WHERE user_id = "{user_id}"')
    conn.commit()

######### СЧЁТ СКРИНШОТОВ #########
def count_screens(user_id, value):
    conn = sqlite3.connect('data/botBD.sqlite')
    cursor = conn.cursor()
    cursor.execute(f'UPDATE storage_users SET screenshots = screenshots + {value} WHERE user_id = "{user_id}"')
    conn.commit()
