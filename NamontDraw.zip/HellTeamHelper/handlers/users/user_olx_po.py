# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇵🇹 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='olx_portugal_email_inquiry')
async def olx_portugal_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/JZ0xUUJ',
            caption='🇵🇹 Запрос почты.',
            reply_markup=GO_BACK_TO_OLX_PORTUGAL_MENU())
    except Exception as e:
        print(e)

# 🇵🇹 Лимит на карте
@dp.callback_query_handler(lambda c: c. data=='olx_portugal_limit')
async def olx_portugal_limit(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/vSUxMpI',
            caption='🇵🇹 Лимит на карте.',
            reply_markup=GO_BACK_TO_OLX_PORTUGAL_MENU())
    except Exception as e:
        print(e)

# 🇵🇹 Push-уведомление
@dp.callback_query_handler(lambda c: c. data=='olx_portugal_push')
async def olx_portugal_push(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/A7T66ML',
            caption='🇵🇹 Push-уведомление.',
            reply_markup=GO_BACK_TO_OLX_PORTUGAL_MENU())
    except Exception as e:
        print(e)