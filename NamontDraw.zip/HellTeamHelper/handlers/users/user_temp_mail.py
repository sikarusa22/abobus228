# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
import asyncio

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

import json
import requests

from onesec_api import Mailbox
from time import sleep
import urllib.request, sqlite3, os
from datetime import datetime, date, timedelta

from handlers.users.user_functions import count_generations

# 📨 Временная почта
@dp.callback_query_handler(lambda c: c. data=='temp_mail')
async def callback_temp_mail(callback_query: types.CallbackQuery):
    try:
        ma = Mailbox('')
        email = f'{ma._mailbox_}@1secmail.com'
        
        await callback_query.message.edit_text(
            f'''
<b>📧 Твоя временная почта: </b><code>{email}</code>

Отправляй на неё письмо, почта проверяется автоматически, каждые 5 секунд.
Если придет новое письмо, мы тебя об этом оповестим.

<u>На 1 почту можно получить только - 1 письмо.</u>
            ''',
            reply_markup=CLOSE_AND_SHOW_INSTRUMENTS_MENU())
        count_generations(callback_query.message.chat.id, 1)

        while True:
            mb = ma.filtred_mail()
            
            if isinstance(mb, list):
                mf = ma.mailjobs('read', mb[0])
                js = mf.json()
                fromm = js['from']
                theme = js['subject']
                mes = js['textBody']

                await callback_query.message.answer(
                    f'''
<b>📩 Новое письмо:</b>

<b>От</b>: {fromm}
<b>Тема</b>: {theme}
<b>Сообщение</b>: {mes}''',
                    disable_web_page_preview = True,
                    reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
                break
            else:
                pass
            await asyncio.sleep(5)
    except Exception as e:
        await callback_query.message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)