# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇷🇴 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='olx_ro_email_inquiry')
async def olx_ro_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/636vjv4',
            caption='🇷🇴 Запрос почты.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Товар оплачен
@dp.callback_query_handler(lambda c: c. data=='olx_ro_item_paid')
async def olx_ro_item_paid(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/qGeK7YY',
            caption='🇷🇴 Товар оплачен.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Правила 2.0
@dp.callback_query_handler(lambda c: c. data=='olx_ro_rules_2')
async def olx_ro_rules_2(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/V461DwE',
            caption='🇷🇴 Правила 2.0.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Лимит на карте
@dp.callback_query_handler(lambda c: c. data=='olx_ro_card_limit')
async def olx_ro_card_limit(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/e9mf6ZQ',
            caption='🇷🇴 Лимит на карте.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Откуда ссылка
@dp.callback_query_handler(lambda c: c. data=='olx_ro_whence_link')
async def olx_ro_whence_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/m2IUzaV',
            caption='🇷🇴 Откуда ссылка.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Включить 3D-S
@dp.callback_query_handler(lambda c: c. data=='olx_ro_3d-s')
async def olx_ro_3d_s(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/4SJhmMg',
            caption='🇷🇴 Включить 3D-S.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Подтверждение
@dp.callback_query_handler(lambda c: c. data=='olx_ro_need_verify')
async def olx_ro_need_verify(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/RMJSoRr',
            caption='🇷🇴 Подтверждение.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)

# 🇷🇴 Пополнить
@dp.callback_query_handler(lambda c: c. data=='olx_ro_replenish_by_300')
async def olx_ro_replenish_by_300(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/5VIGpIp',
            caption='🇷🇴 Пополнить.',
            reply_markup=GO_BACK_TO_OLX_ROMANIA_MENU())
    except Exception as e:
        print(e)