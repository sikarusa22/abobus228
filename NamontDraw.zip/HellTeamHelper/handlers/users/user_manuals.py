# — *— coding: utf— 8 — *—
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

two_better_than_one = """
<b>📗 2.0 лучше чем 1.0.</b>

<b>Большая проблема в скаме 1.0</b> — ограниченное количество мамонтов, которых ты можешь развести.

Даже выставив айфон за 5000р, в день вам будет приходить 20—30 сообщений от мамонтов, 50% из них будут прошарены и по вашей ссылке никогда не перейдут, и у вас остаётся 10 человек, из которых залетит максимум 1—2.

<b>Чем же так прекрасен 2.0 ?</b>

Самое лучшее — неограниченное количество мамонтов, которых ты можешь обработать за день.

Я за день обрабатываю 200—300 мамонтов, и даже если из них будет 75% прошарены, то останеться ещё 50 мамонтов, которых можно скамануть.
"""
novice_errors = """
<b>📘 Ошибки новичков.</b>

В этом мануале будет описана одна из самых больших ошибок которые делают новички в скаме.

Пишешь ты мамонту, прогреваешь, спрашиваешь про куфар доставку, и наконец-то, мамонт пишет что в душе не ебет что это такое.
Как только видишь это сообщение, ты должен моментально зайти с ним в переписку и скинуть этот скрин.

<b>Сразу после скрина пишем:</b> «Вот тут описано как это работает»

<b>У некоторых появился вопрос «А зачем ?»</b>

Всё очень просто, если вы будете игнорировать мамонта 5-15 минут, то он за это время успеет прочитать про эту доставку, а по первым ссылкам которые выдают после того как мамонт вписал в Google «Как работает Куфар доставка» выдаются статьи как людей наебали.

Но, даже если мамонт не дойдёт до этих статей, то на официальном сайте он найдёт совершенно другую информацию о Куфар доставке, и уже никогда не перейдёт по вашей ссылке.
"""
effective_work = """
<b>📚 Эффективный ворк.</b>

<b>Ворк обычного воркера:</b>

Воркер заходит на куфар и начинает набирать мамонтов, набирает минут 10-15 и видит что у него уже 5 сообщений и сразу отвечает на них.
По моему мнению это не очень эффективно, ниже способ получше.

<b>Продвинутый ворк:</b>

Вы заходите на куфар и набираете мамонтов, но не стоит сразу им отвечать, лучше подождать пока у вас не наберется 15-30 сообщений от мамонтов, все ответы будут по типу «Актуально», «Да, продаю».

После того как ты увидел что у тебя эти самые 15-30 сообщений - начинаешь отвечать мамонтам, сначала стоит отвечать мамонтам которые в самом низу чатов, так как они ждали вас дольше всех.

И так, всем мамонтам мы ответили «Отлично, в каком состоянии?», и далее опять идём на Куфар, и начинаем набирать мамонтов ещё 10 минут, чтобы прошлые мамонты которым вы написали «Отлично, в каком состоянии?» успели ответить.

Итак прошло 15 минут, у вас опять 20-30 сообщений, вы снова отвечаете им и после этого опять идёте набирать мамонтов 10-15 минут.

В итоге получается, что у вас бесконечный поток мамонтов, которые каждую минуту вам отвечают, и каждые 10 минут делаем новый круг, не забывая искать новых мамонтов.

<i>Вот таким способом можно обрабатывать огромное количество мамонтов в день.</i>
"""
mammoth_limits = """
<b>📈 Лимиты мамонта.</b>

Перед успешной мамонтизацией, следует надоумить мамонта поднять лимиты своей карты на оплату в интернете, скинув ему ссылку ниже, дабы списать побольше, ну или хотябы что-то списать.

<i>Ссылка: https://youtu.be/cbDwBdLQaAw</i>
"""
carding_stealer = '''
<b>Как обезопаситься от стиллера.</b>

<b>Что подвергается стиллу чаще всего:</b>

• Данные банков, криптовалютных бирж и кошельков
• Аккаунты игровых платформ и соц. сетей

<b>Методы борьбы за сохранность паролей:</b>

• Не сохранять пароли в браузере, лучше всего держать их на бумажке или вовсе в голове
• Проверять на вирусы через Virus Total, если даже файл уже там лежит.
• Использовать антивирусы.
• Периодически проверять операционную систему программами типо: Hitman Pro, Malwarebytes, ESET.

<b>Что делать если уже попал на стиллер:</b>

1. Проверить свой ПК программой Malwarebytes.
2. Изменить все пароли и включить двух-факторную аутентификацию.

<b>Заключение.</b>

Не качайте файлы из заведомо подозрительных ресурсов, потому-что никакой антивирус не заменит банальная осторожность, удачи!
'''
find_out_merchants = '''
<b>Поиск мерчей, шопой и казиков.</b>

Здарова! Наверное все хотели узнать как найти шопы, казики и так далее с 2д платегой, но не у всех это получалось.
Сейчас перед вами есть возможность узнать как же найти сайт где мерч принимает оплату в 2д.

Переходим на сайт https://builtwith.com (этот сайт что-то вроде базы знаний о технологиях).

Если ввести в поисковую строку сайта нужный вам шоп то вы получите полную информацию о нём.
В графе E-commerce вы увидите название мерча который используется на сайте.

Условно говоря на нашем сайте используется cart32, кликнув на название технологии мы сможем просмотреть сайты которые её используют.

Или если знаете название мерча то можете сразу вводить его в строку поиска и будет вам счастье.
'''
find_out_sberbank_balance = '''
<b>Узнаём точный баланс карты Сбера.</b>

<b>Нам потребуется:</b>

1.Номера мамонта к которому привязан Сбер.

2. SIP телефония (подмена номера).

<b>Приступим:</b>

1. Звоним на 900, подставляя на исходящий, номер нужного мамонта.

2. Запрашиваем баланс у робота.

3. Вас попросит назвать последние 4 цифры карты, говорим на рандом.

4. Дальше робот сообщает о доступных картах и предлагает продиктовать остаток по ним.

<i>P.S Таким лайфхаком частенько пользуются банковские мошенники, всем удачи!</i>
'''

# ◀️ Назад (в 🔖 Помощник)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_helper_menu')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="🔖 Помощник",
        reply_markup=HELPER_MENU())

# 📃 Мануалы 📃
@dp.callback_query_handler(lambda c: c. data=='helper_manuals')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('📃 Мануалы', reply_markup=MANUALS_MENU())

# ◀️ Назад (в 📃 Мануалы)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_manuals_menu')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="📃 Мануалы",
        reply_markup=MANUALS_MENU())

# 🐘 Скам
@dp.callback_query_handler(lambda c: c. data=='manuals_scam')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="🐘 Скам",
        reply_markup=SCAM_MENU())

# ◀️ Назад (в 🐘 Скам)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_scam_menu')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="🐘 Скам",
        reply_markup=SCAM_MENU())

# ◀️  Назад (в 🐘 Скам (альтернатива))
@dp.callback_query_handler(lambda c: c. data=='alternative_go_back_to_scam_menu')
async def callback_function(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await callback_query.message.answer(
            text="🐘 Скам",
            reply_markup=SCAM_MENU())
    except Exception as e:
        print(e)

# 💳 Кардинг
@dp.callback_query_handler(lambda c: c. data=='manuals_carding')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="💳 Кардинг",
        reply_markup=CARDING_MENU())

# ◀️ Назад (в 💳 Кардинг)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_carding_menu')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="💳 Кардинг",
        reply_markup=CARDING_MENU())

# ◀️ Назад (в 💳 Кардинг (альтернатива)
@dp.callback_query_handler(lambda c: c. data=='alternative_go_back_to_carding_menu')
async def callback_function(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await callback_query.message.answer(
            text="💳 Кардинг",
            reply_markup=CARDING_MENU())
    except Exception as e:
        print(e)

# 🕳 Анонимность
@dp.callback_query_handler(lambda c: c. data=='manuals_anonymity')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="🕳 Анонимность",
        reply_markup=ANONYMITY_MENU())

# ◀️ Назад (в 🕳 Анонимность)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_anonymity_menu')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="🕳 Анонимность",
        reply_markup=ANONYMITY_MENU())

# 📘 Прочее
@dp.callback_query_handler(lambda c: c. data=='manuals_other_things')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="📘 Прочее",
        reply_markup=OTHER_MENU())

# ◀️ Назад (в 📘 Прочее)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_other_menu')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text="📘 Прочее",
        reply_markup=OTHER_MENU())

# MANUALS: 🐘 Скам

# 📗 2.0 лучше чем 1.0
@dp.callback_query_handler(lambda c: c. data=='two_better_than_one')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=two_better_than_one,
        reply_markup=GO_BACK_TO_SCAM_MENU())

# 📘 Ошибки новичков
@dp.callback_query_handler(lambda c: c. data=='novice_errors')
async def callback_function(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            'https://telegra.ph/file/7654207cb7e5ead92ba8b.jpg',
            caption=novice_errors,
            reply_markup=ALTERNATIVE_GO_BACK_TO_SCAM_MENU())
    except Exception as e:
        print(e)

# 📚 Эффективный ворк
@dp.callback_query_handler(lambda c: c. data=='effective_work')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=effective_work,
        reply_markup=GO_BACK_TO_SCAM_MENU())

# 📈 Лимиты мамонта
@dp.callback_query_handler(lambda c: c. data=='mammoth_limits')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=mammoth_limits,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_SCAM_MENU())

# MANUALS:💳 Кардинг

# 🛡 Стиллер
@dp.callback_query_handler(lambda c: c. data=='carding_stealer')
async def callback_function(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            'https://telegra.ph/file/4e7898115920ef7d450d3.jpg',
            caption=carding_stealer,
            reply_markup=ALTERNATIVE_GO_BACK_TO_CARDING_MENU())
    except Exception as e:
        print(e)

# 👔 Поиск мерчей
@dp.callback_query_handler(lambda c: c. data=='find_out_merchants')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=find_out_merchants,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 💳 Обнал PayPal
@dp.callback_query_handler(lambda c: c. data=='cashout_paypal')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=cashout_paypal,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 💰Обнал Coinbase
@dp.callback_query_handler(lambda c: c. data=='cashout_coinbase')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=cashout_paypal,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 🏬 Вбив AliExpress
@dp.callback_query_handler(lambda c: c. data=='vbv_aliexpress')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=vbv_aliexpress,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 🏦 Обнал Tinkoff
@dp.callback_query_handler(lambda c: c. data=='cashout_tinkoff')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=cashout_tinkoff,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 🔑 Вбив ключей
@dp.callback_query_handler(lambda c: c. data=='vbv_keys')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=vbv_keys,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 🛍 Вбив Asos
@dp.callback_query_handler(lambda c: c. data=='vbv_asos')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=vbv_asos,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 🔍 Сбер баланс
@dp.callback_query_handler(lambda c: c. data=='find_out_sberbank_balance')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=find_out_sberbank_balance,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 💝 Вбив Patreon
@dp.callback_query_handler(lambda c: c. data=='vbv_patreon')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=vbv_patreon,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 👟 Вбив Adidas
@dp.callback_query_handler(lambda c: c. data=='vbv_adidas')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=vbv_adidas,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# ✈️ Обнал TG
@dp.callback_query_handler(lambda c: c. data=='cashout_telegram')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=cashout_telegram,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())

# 💨 Вбив Steam
@dp.callback_query_handler(lambda c: c. data=='vbv_steam')
async def callback_function(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text=vbv_steam,
        disable_web_page_preview=True,
        reply_markup=GO_BACK_TO_CARDING_MENU())