# - *- coding: utf- 8 - *-
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.builtin import CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton

import asyncio

from data.config import admins

from filters import IsPrivate, IsWork, IsUser
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.db_api.sqlite import *
from utils.other_func import clear_firstname

from loader import dp, bot
from states.state_functions import *
from utils.other_func import clear_firstname

from time import sleep
import sqlite3, os
from datetime import datetime, date, timedelta

from data.config import *

# Уведомляет юзера о тех. работах
@dp.message_handler(IsWork())
async def send_work_message(message: types.Message):
    await bot.delete_message(message.chat.id, message.message_id)
    await message.answer("<b>🔴 Бот находится на технических работах.</b>")

# Уведомляет юзера о тех. работах (инлайн)
@dp.callback_query_handler(IsWork())
async def send_work_message(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.answer("🔴 Бот находится на технических работах.")

# Обработка кнопки "На главную" и команды "/start"
@dp.message_handler(IsPrivate(), CommandStart(), state="*")
async def bot_start(message: types.Message, state: FSMContext):
    await state.finish()

    first_name = clear_firstname(message.from_user.first_name)
    get_user_id = get_userx(user_id=message.from_user.id)
    
    if get_user_id is None:
        if message.from_user.username is not None:
            get_user_login = get_userx(user_login=message.from_user.username)
            if get_user_login is None:
                add_userx(message.from_user.id, message.from_user.username, first_name, datetime.today().replace(microsecond=0), 0, 0, 0, 0)
                try:
                    await bot.send_message(
                        admins[0],
                        text=f'🎉 Новый <a href="tg://user?id={message.from_user.id}">пользователь</a>.',
                        reply_markup=CLOSE_BTN())
                except Exception as e:
                    print(e)
            else:
                delete_userx(user_login=message.from_user.username)
                add_userx(message.from_user.id, message.from_user.username, first_name, datetime.today().replace(microsecond=0), 0, 0, 0, 0)
        else:
            add_userx(message.from_user.id, message.from_user.username, first_name, datetime.today().replace(microsecond=0), 0, 0, 0, 0)
    else:
        if first_name != get_user_id[3]:
            update_userx(get_user_id[1], user_name=first_name)
        if message.from_user.username is not None:
            if message.from_user.username.lower() != get_user_id[2]:
                update_userx(get_user_id[1], user_login=message.from_user.username.lower())

    await bot.delete_message(message.chat.id, message.message_id)
    await message.answer(
        text="<b>Меню ⤵️</b>",
        reply_markup=check_user_out_func(message.from_user.id))

@dp.message_handler(IsUser())
@dp.callback_query_handler(IsUser())
async def send_user_message(message: types.Message):
    await bot.delete_message(message.chat.id, message.message_id)
    await bot.send_message(
        message.from_user.id,
        "<b>❕ Ваш профиль не был найден.</b>\n\n▶ Введите /start")