# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
import json
from PIL import Image, ImageFont, ImageDraw
from time import sleep
import sqlite3, os
from datetime import datetime, date, timedelta
from states import StorageFunctions
from handlers.users.user_functions import count_generations

# 🖌 Отрисовка
@dp.callback_query_handler(lambda c: c.data=='writings')
async def callback_writings(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🖌 Отрисовка.', reply_markup=WRITINGS_MENU())

def Comissions(value):
    try:
        return str("{0:.2f}".format(float(value)))
    except:
        return 0

# 🐥 Qiwi: баланс
@dp.callback_query_handler(lambda c: c.data=='qiwi_balance')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Введите данные.</b>

Отправьте желаемый баланс <code>(нап: 1500,00)</code>
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_qiwi_balance.set()

# 🐥 Qiwi: баланс (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_qiwi_balance)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_qiwi_balance.set()

        text = message.text + ' ₽'

        qiwi = Image.open("photos/image_sources/qiwi_balance.png")
        fnt = ImageFont.truetype("Fonts/Roboto-Bold.ttf", 100)
        W = 1080
        w, h = fnt.getsize(text)
        d = ImageDraw.Draw(qiwi)
        d.text(((W - w) / 2, 296), text, font=fnt, fill=(255, 255, 255, 255))

        qiwi.save("photos/image_cache/qiwi_balance.png", "PNG")
        img = open('photos/image_cache/qiwi_balance.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🐥 Qiwi: баланс.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🐥 Qiwi: перевод
@dp.callback_query_handler(lambda c: c.data=='qiwi_transfer')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Сумма перевода (нап: <code>500</code>)
2️⃣ - Номер Qiwi кошелька (нап: <code>+79XXXXXXXXX</code>)
3️⃣ - Дата и время (нап: <code>08.08.2021 в 08:08</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_qiwi_transfer.set()

# 🐥 Qiwi: перевод (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_qiwi_transfer)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_qiwi_transfer.set()

        text = message.text.split('\n')
        money = text[0] + " ₽"
        money2 = "- " + text[0].strip() + " ₽"
        phone = text[1].strip()
        date_time = text[2].strip()

        qiwi = Image.open('photos/image_sources/qiwi_check.png')

        font1 = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 53)
        font2 = ImageFont.truetype('Fonts/Roboto-Regular.ttf', 38)
        font3 = ImageFont.truetype('Fonts/Roboto-Regular.ttf', 45)
        font4 = ImageFont.truetype('Fonts/Roboto-Regular.ttf', 45)

        W = 1080
        w1, h1 = font1.getsize(money2)
        w2, h2 = font1.getsize(phone)

        d = ImageDraw.Draw(qiwi)
        d.text(((W-w1)/2,685), money2, font=font1, fill=(0,0,0,255))
        d.text(((W-w2)/2 + 60,614), phone, font=font2, fill=(153,153,153,255))
        d.text((56,1890), date_time, font=font3, fill=(0,0,0,255))
        d.text((56,2072), money, font=font4, fill=(0,0,0,255))

        qiwi.save("photos/image_cache/qiwi_check.png", "PNG")
        img = open('photos/image_cache/qiwi_check.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🐥 Qiwi: баланс.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🐥 Qiwi: получение (ПК)
@dp.callback_query_handler(lambda c: c.data=='qiwi_receiving_on_pc')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Номер кошелька (нап: <code>+7 967 555‑00‑11</code>)
2️⃣ - Баланс (нап: <code>2500.00</code>)
3️⃣ - Название перевода (нап: <code>QIWI Кошелек +79675550011</code>)
4️⃣ - Сумма перевода (нап: <code>2500.00</code>)
5️⃣ - Комиссия (нап: <code>50</code>)
6️⃣ - Дата операции (нап: <code>08.08.2021 в 08:08</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_qiwi_receiving_on_pc.set()

# 🐥 Qiwi: получение (ПК) (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_qiwi_receiving_on_pc)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_qiwi_receiving_on_pc.set()

        text = message.text.split('\n')
        phone = text[0]
        money = text[1] + ' ₽'
        name = text[2]
        payment = Comissions(float(text[3]) - float(text[4])).replace('.', ',')
        comission = text[4]
        date = text[5]
        phone1 = phone.replace(' ', '').replace('‑', '')

        qiwis = Image.open('photos/image_sources/qiwi_check_pc.png')

        font1 = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 20)
        font2 = ImageFont.truetype('Fonts/Roboto-Regular.ttf', 14)
        font3 = ImageFont.truetype('Fonts/MuseoSans-300.ttf', 21)
        font4 = ImageFont.truetype('Fonts/MuseoSans-300.ttf', 29)
        font5 = ImageFont.truetype('Fonts/MuseoSans-300.ttf', 16)
        font6 = ImageFont.truetype('Fonts/Roboto-Regular.ttf', 15)
        font7 = ImageFont.truetype('Fonts/MuseoSans-500.ttf', 16)

        d = ImageDraw.Draw(qiwis)

        d.text((1404,20), phone, font=font2, fill=(153,153,153,255))
        d.text((1404,40), money, font=font1, fill=(0,0,0,255))
        d.text((497,494), name, font=font3, fill=(0,0,0,255))
        d.text((677,553), payment, font=font5, fill=(0,0,0,255))
        d.text((677,583), comission, font=font5, fill=(0,0,0,255))
        d.text((677,613), payment, font=font7, fill=(0,0,0,255))
        d.text((677,708), date, font=font5, fill=(0,0,0,255))
        d.text((677,770), phone1, font=font5, fill=(0,0,0,255))

        W = 1903
        w, h = font4.getsize(payment)
        w1, h1 = font5.getsize(payment)
        w2, h2 = font5.getsize(comission)
        w3, h3 = font7.getsize(payment)

        d.text(((W - w - 810), 489), payment, font=font4, fill='#4bbd5c')
        d.text(((677 + w1 + 7), 555), '₽', font=font6, fill='#000')
        d.text(((677 + w2 + 7), 585), '₽', font=font6, fill='#000')
        d.text(((677 + w3 + 7), 615), '₽', font=font6, fill='#000')

        qiwis.save("photos/image_cache/qiwi_check_pc.png", "PNG")
        img = open('photos/image_cache/qiwi_check_pc.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🐥 Qiwi: получение (ПК).</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🇷🇺 Сбербанк: баланс
@dp.callback_query_handler(lambda c: c.data=='sberbank_balance')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Баланс (нап: <code>8000</code>)
3️⃣ - Последние 4 цифры карты (нап: <code>0088</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_sberbank_balance.set()

# 🇷🇺 Сбербанк: баланс (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_sberbank_balance)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_sberbank_balance.set()

        text = message.text.split("\n")
        time = text[0]
        name = text[1] + " ₽"
        money = text[2]

        sber = Image.open('photos/image_sources/sber_balance.png')

        font_time = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 16)
        font_name = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 24)
        font_money = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 18)

        d = ImageDraw.Draw(sber)

        d.text((15,20), time, font=font_time, fill=(225, 238, 229,255))

        if (len(text[1]) == 4):
            d.text((490,543), name, font=font_name, fill=(37,152,97,255))
        elif (len(text[1]) <= 3):
            d.text((500,543), name, font=font_name, fill=(37,152,97,255))
        elif (len(text[1]) == 5):
            d.text((480,543), name, font=font_name, fill=(37,152,97,255))
        elif (len(text[1]) == 6):
            d.text((455,543), name, font=font_name, fill=(37,152,97,255))
        elif (len(text[1]) == 7):
            d.text((430,543), name, font=font_name, fill=(37,152,97,255))
        elif (len(text[1]) == 8):
            d.text((400,543), name, font=font_name, fill=(37,152,97,255))
        elif (len(text[1]) == 9):
            d.text((370,543), name, font=font_name, fill=(37,152,97,255))

        d.text((115, 580), money, font=font_money, fill=(132,132,132,255))

        sber.save("photos/image_cache/sber_balance.png", "PNG")
        img = open('photos/image_cache/sber_balance.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🇷🇺 Сбербанк: баланс.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🇷🇺 Сбербанк: перевод
@dp.callback_query_handler(lambda c: c.data=='sberbank_transfer')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Сумма перевода (нап: <code>8000</code>)
3️⃣ - ФИО (нап: <code>Григорьева Анна А</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_sberbank_transfer.set()

# 🇷🇺 Сбербанк: перевод (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_sberbank_transfer)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_sberbank_transfer.set()

        text = message.text.split("\n")
        time = text[0]
        name = text[1] + " ₽"
        money = text[2]

        sbert = Image.open('photos/image_sources/sber_transfer.png')

        font_time = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 16)
        font_name = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 43)
        font_money = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 21)

        d = ImageDraw.Draw(sbert)

        d.text((15,20), time, font=font_time, fill=(225, 238, 229,255))

        if (len(text[1]) == 4):
            d.text((185,270), name, font=font_name, fill=(255,255,255,255))
        elif (len(text[1]) == 3):
            d.text((195,270), name, font=font_name, fill=(255,255,255,255))
        elif (len(text[1]) == 5):
            d.text((170,270), name, font=font_name, fill=(255,255,255,255))
        
        d.text((80, 835), money, font=font_money, fill=(73,73,73,255))

        sbert.save("photos/image_cache/sber_transfer.png", "PNG")
        img = open('photos/image_cache/sber_transfer.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🇷🇺 Сбербанк: баланс.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🇺🇦 Монобанк: баланс
@dp.callback_query_handler(lambda c: c.data=='monobank')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Баланс (нап: <code>5000</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_monobank.set()

# 🇺🇦 Монобанк: баланс (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_monobank)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_monobank.set()

        text = message.text.split("\n")

        time = text[0]

        mono = Image.open('photos/image_sources/old_monobank_balance.png')

        font_time = ImageFont.truetype('Fonts/ArialRegular.ttf', 26)
        font_main = ImageFont.truetype('Fonts/Roboto-Bold.ttf', 64)

        d = ImageDraw.Draw(mono)

        d.text((28, 14), time, font=font_time, fill=(255,255,255,255))

        W = 720
        W1 = 0
        w2, h2 = font_main.getsize(text[1])

        d.text(((W1 + 68), 225), text[1], font=font_main, fill=(255,255,255,255))

        mono.save("photos/image_cache/old_monobank_balance.png", "PNG")
        img = open('photos/image_cache/old_monobank_balance.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🇺🇦 Монобанк: баланс.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 👨‍🦳 Тинькофф: перевод
@dp.callback_query_handler(lambda c: c.data=='tinkoff_transfer')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Сумма перевода (нап: <code>8000</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_tinkoff.set()

# 👨‍🦳 Тинькофф: перевод (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_tinkoff)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_tinkoff.set()

        text = message.text.split("\n")
        
        time = text[0]
        money = text[1] + " ₽"
        
        tink = Image.open('photos/image_sources/tinkoff_transfer.png')
        
        font_money = ImageFont.truetype('Fonts/ArialRegular.ttf', 54)
        font_time = ImageFont.truetype('Fonts/Roboto-Medium.ttf', 21)
        
        d = ImageDraw.Draw(tink)

        d.text((340,6), time, font=font_time, fill=(255,255,255,255))

        if (len(text[1]) == 3):
            d.text((290,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 4):
            d.text((280,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 5):
            d.text((270,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 6):    
            d.text((260,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 7):    
            d.text((240,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 8):    
            d.text((220,600), money, font=font_money, fill=(255,255,255,255))

        tink.save("photos/image_cache/tinkoff_transfer.png", "PNG")
        img = open('photos/image_cache/tinkoff_transfer.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>👨‍🦳 Тинькофф: перевод.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 👨‍🦳 Тинькофф: Авито
@dp.callback_query_handler(lambda c: c.data=='tinkoff_transfer_avito')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Сумма перевода (нап: <code>8000</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_tinkoff_avito.set()

# 👨‍🦳 Тинькофф: Авито (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_tinkoff_avito)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_tinkoff_avito.set()

        text = message.text.split("\n")
        time = text[0]
        money = text[1] + " ₽"
        tink = Image.open('photos/image_sources/tk_avito_transfer.png')
        font_money = ImageFont.truetype('Fonts/ArialRegular.ttf', 54)
        font_time = ImageFont.truetype('Fonts/Roboto-Medium.ttf', 21)
        d = ImageDraw.Draw(tink)

        d.text((340,6), time, font=font_time, fill=(255,255,255,255))

        if (len(text[1]) == 3):
            d.text((290,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 4):
            d.text((280,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 5):
            d.text((270,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 6):    
            d.text((260,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 7):    
            d.text((240,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 8):    
            d.text((220,600), money, font=font_money, fill=(255,255,255,255))

        tink.save("photos/image_cache/tinkoff_transfer_avito.png", "PNG")
        img = open('photos/image_cache/tinkoff_transfer_avito.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>👨‍🦳 Тинькофф: перевод Авито.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 👨‍🦳 Тинькофф: Юла
@dp.callback_query_handler(lambda c: c.data=='tinkoff_transfer_youla')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Сумма перевода (нап: <code>8000</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_tinkoff_youla.set()

# 👨‍🦳 Тинькофф: Юла (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_tinkoff_youla)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_tinkoff_youla.set()

        text = message.text.split("\n")
        time = text[0]
        money = text[1] + " ₽"
        tink = Image.open('photos/image_sources/tk_youla_transfer.png')
        font_money = ImageFont.truetype('Fonts/ArialRegular.ttf', 54)
        font_time = ImageFont.truetype('Fonts/Roboto-Medium.ttf', 21)
        d = ImageDraw.Draw(tink)

        d.text((340,6), time, font=font_time, fill=(255,255,255,255))

        if (len(text[1]) == 3):
            d.text((290,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 4):
            d.text((280,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 5):
            d.text((270,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 6):    
            d.text((260,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 7):    
            d.text((240,600), money, font=font_money, fill=(255,255,255,255))
        elif (len(text[1]) == 8):    
            d.text((220,600), money, font=font_money, fill=(255,255,255,255))

        tink.save("photos/image_cache/tinkoff_transfer_youla.png", "PNG")
        img = open('photos/image_cache/tinkoff_transfer_youla.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>👨‍🦳 Тинькофф: перевод Юла.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🇺🇦 Спортбанк
@dp.callback_query_handler(lambda c: c.data=='sportbank')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Дата операции (нап: <code>08 августа 2021, 08:08</code>)
3️⃣ - Сумма без копеек (нап: <code>1000</code>)
4️⃣ - Копейки (нап: <code>00</code>)
5️⃣ - Баланс (нап: <code>2000.00</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_sportbank.set()

# 🇺🇦 Спортбанк (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_sportbank)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_sportbank.set()

        text = message.text.split('\n')

        time = text[0]
        paytime = text[1]
        money_1 = text[2]
        money_2 = '.' + text[3] + ' ₴'
        balance = text[4] + ' ₴'

        sport = Image.open('photos/image_sources/sportbank.png')

        font_21 = ImageFont.truetype('Fonts/Iphone-Regular.ttf', 21)
        font_31 = ImageFont.truetype('Fonts/Iphone-Regular.ttf', 31)
        font_40 = ImageFont.truetype('Fonts/Iphone-Medium.ttf', 48)
        font_48 = ImageFont.truetype('Fonts/Iphone-Medium.ttf', 100)

        d = ImageDraw.Draw(sport)

        d.text((340,6), time, font=font_21, fill=(255,255,255,255))
        d.text((130,675), balance, font=font_31, fill=(0,0,0,255))

        W, H = (719, 1280)

        w, h = font_31.getsize(paytime)
        w1, h1 = font_48.getsize(money_1)
        w2, h2 = font_40.getsize(money_2)
            
        d.text(((W - w) / 2 , 385), paytime, font = font_31, fill='#6B6B6B')
        d.text(((W - w1 - w2) / 2, 430), money_1, font = font_48, fill='#000')
        d.text(((W + w1 - w2) / 2, 480), money_2, font = font_40, fill='#000')

        sport.save("photos/image_cache/sportbank.png", "PNG")
        img = open('photos/image_cache/sportbank.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🇺🇦 Спортбанк: перевод.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🇧🇾 Куфар: перевод
@dp.callback_query_handler(lambda c: c.data=='write_kufar')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>8:08</code>)
2️⃣ - Дата операции (нап: <code>08.08.2021 08:08</code>)
3️⃣ - Сумма перевода (нап: <code>800</code>)
4️⃣ - Последние 4 цифры карты (нап: <code>0888</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_kufar.set()

# 🇧🇾 Куфар: перевод (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_kufar)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_kufar.set()
        text = message.text.split("\n")

        time = text[0]
        date = text[1]
        profit = text[2]
        summ = text[2] + " BYN"
        card = text[3]

        kufar = Image.open('photos/image_sources/kufar_transfer.png')

        font_time = ImageFont.truetype('Fonts/Iphone-Regular.ttf', 21)
        font_main = ImageFont.truetype('Fonts/Iphone-Regular.ttf', 32)
            
        d = ImageDraw.Draw(kufar)

        d.text((330,6), time, font=font_time, fill=(255,255,255,255))
        d.text((439,266), date, font=font_main, fill=(0,0,0,255))
        d.text((598,851), card, font=font_main, fill=(0,0,0,255))

        W = 720
        w1, h1 = font_main.getsize(profit)
        w2, h2 = font_main.getsize(summ)

        d.text(((W - 35 - w1), 720), profit, font=font_main, fill=(0,0,0,255))
        d.text(((W - 35 - w2), 782), summ, font=font_main, fill=(0,0,0,255))

        kufar.save("photos/image_cache/kufar.png", "PNG")
        img = open('photos/image_cache/kufar.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🇧🇾 Куфар: перевод.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 🇰🇿 Каспи: баланс
@dp.callback_query_handler(lambda c: c.data=='write_kaspi')
async def callback_qiwi_balance(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>Заполните форму.</b>

1️⃣ - Системное время (нап: <code>08:08</code>)
2️⃣ - Баланс (нап: <code>500,00</code>)
3️⃣ - Последние 4 цифры карты (нап: <code>0888</code>)
        ''',
        reply_markup=CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU())
    await StorageFunctions.here_write_kaspi.set()

# 🇰🇿 Каспи: баланс (ОТРИСОВКА)
@dp.message_handler(state=StorageFunctions.here_write_kaspi)
async def make_screen(message: types.Message, state: FSMContext):
    try:
        await StorageFunctions.here_write_kaspi.set()
        text = message.text.split("\n")

        time = text[0]
        balance = text[1]
        last = text[2]

        kaspi = Image.open('photos/image_sources/kaspi_balance.png')

        font_time = ImageFont.truetype('Fonts/ArialRegular.ttf', 21)
        font_card = ImageFont.truetype('Fonts/ArialRegular.ttf', 17)
        font_main = ImageFont.truetype('Fonts/ArialRegular.ttf', 28)
            
        d = ImageDraw.Draw(kaspi)

        d.text((20, 20), time, font=font_time, fill=(255,255,255,255))
        d.text((128, 259.6), last, font=font_card, fill=(159,159,159,255))

        W = 576
        w1, h1 = font_main.getsize(balance)

        d.text(((W - 48 - w1), 220), balance, font=font_main, fill=(48,48,48,255))

        kaspi.save("photos/image_cache/kufar.png", "PNG")
        img = open('photos/image_cache/kufar.png', 'rb')

        await bot.delete_message(message.chat.id, message.message_id)
        del d

        await bot.send_photo(
            message.chat.id,
            photo=img,
            caption=f'<b>🇰🇿 Каспи: баланс.</b>',
            reply_markup=CLOSE_BTN())
        await state.finish()
        count_generations(message.chat.id, 1)
    except Exception as e:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer('Произошла ошибка, попробуйте еще раз.')
        print(e)

# 