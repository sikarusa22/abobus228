# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname
import sqlite3, os
from datetime import datetime, date, timedelta

# Разбив сообщения на несколько, чтобы не прилетало ограничение от ТГ
def split_messages(get_list, count):
    return [get_list[i:i + count] for i in range(0, len(get_list), count)]

# Главное меню
@dp.message_handler(IsPrivate(), text="📖 Меню", state="*")
async def main_menu(message: types.Message, state: FSMContext):
    await state.finish()
    await bot.delete_message(message.chat.id, message.message_id)
    await message.answer(text='📖 Меню', reply_markup=MAIN_MENU())

# Назад в главное меню
@dp.callback_query_handler(lambda c: c. data=='go_back_to_main_menu', state="*")
async def go_back_to_main_menu(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text('📖 Меню', reply_markup=MAIN_MENU())

# 🔖 Помощник
@dp.callback_query_handler(lambda c: c. data=='helper', state="*")
async def helper(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text('🔖 Помощник', reply_markup=HELPER_MENU())

# 🛠 Инструменты
@dp.callback_query_handler(lambda c: c. data=='instruments', state="*")
async def instruments(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await callback_query.message.edit_text('🛠 Инструменты', reply_markup=INSTRUMENTS_MENU())

# ℹ️ Информация
@dp.callback_query_handler(lambda c: c. data=='information', state="*")
async def information(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    get_status_user = get_user_profile(callback_query.from_user.id)
    await callback_query.message.edit_text(get_status_user, reply_markup=INFO_BTNS())

# 📊 Статистика
@dp.callback_query_handler(lambda c: c. data=='show_personal_statistic', state="*")
async def show_personal_statistic(callback_query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    get_personal_user_statistic = get_user_statistic(callback_query.from_user.id)
    await callback_query.message.edit_text(get_personal_user_statistic, reply_markup=INFO_BTNS())