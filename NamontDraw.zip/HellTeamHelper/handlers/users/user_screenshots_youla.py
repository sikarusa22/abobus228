# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
# 🇷🇺 Юла
@dp.callback_query_handler(lambda c: c. data=='youla_screenshots')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇷🇺 Юла', reply_markup=YOULA_MENU())

# ◀️ Назад (в 🇷🇺 Юла)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_youla_menu')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇷🇺 Юла', reply_markup=YOULA_MENU())

# SCREENSHOTS: 🇷🇺 Юла

# 🇷🇺 2.0 900
@dp.callback_query_handler(lambda c: c. data=='youla_two_900')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/lBuc8CR')
        media.attach_photo('https://imgur.com/bFmugSA')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 2.0 900.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 2.0 — домен
@dp.callback_query_handler(lambda c: c. data=='youla_two_domen')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/gNpsLVE',
            caption='🇷🇺 2.0 — домен.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 3.0 — запрос кода
@dp.callback_query_handler(lambda c: c. data=='youla_three_code_inquiry')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/XndrGfR',
            caption='🇷🇺 3.0 — запрос кода.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='youla_email_inquiry')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/6xEKKSs')
        media.attach_photo('https://imgur.com/VyZyMfA')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 Запрос почты.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 CVC код
@dp.callback_query_handler(lambda c: c. data=='youla_cvc_code')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/FAslDzb')
        media.attach_photo('https://imgur.com/HrvnHcq')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 CVC код.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Нет уведомления
@dp.callback_query_handler(lambda c: c. data=='youla_no_notification')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/uQgLNLZ')
        media.attach_photo('https://imgur.com/mhnCTQQ')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 Нет уведомления.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Получить по ссылке
@dp.callback_query_handler(lambda c: c. data=='youla_get_by_link')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/zSU42ex',
            caption='🇷🇺 Получить по ссылке.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Возврат
@dp.callback_query_handler(lambda c: c. data=='youla_return')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/CH0ep6N')
        media.attach_photo('https://imgur.com/B3WYsjf')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 Возврат.',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)

# 🇷🇺 Доставка (ссылка)
@dp.callback_query_handler(lambda c: c. data=='youla_delivery_link')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/YVl3KZI')
        media.attach_photo('https://imgur.com/1cB7AGD')
        media.attach_photo('https://imgur.com/govVvhW')
        media.attach_photo('https://imgur.com/FeuUOPl')
        media.attach_photo('https://imgur.com/NXmMCSt')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🇷🇺 Как работает доставка (ссылка)..',
            reply_markup=GO_BACK_TO_YOULA_MENU())
    except Exception as e:
        print(e)