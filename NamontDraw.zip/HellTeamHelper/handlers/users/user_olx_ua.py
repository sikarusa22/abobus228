# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇺🇦 1.0 Как работает доставка
@dp.callback_query_handler(lambda c: c. data=='olx_ukraine_one_delivery_work')
async def olx_ukraine_one_delivery_work(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/cUayK0R',
            caption='🇺🇦 1.0 Как работает доставка.',
            reply_markup=GO_BACK_TO_OLX_UKRAINE_MENU())
    except Exception as e:
        print(e)

# 🇺🇦 2.0 Как работает доставка
@dp.callback_query_handler(lambda c: c. data=='olx_ukraine_two_delivery_work')
async def olx_ukraine_two_delivery_work(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/YUbvtO4',
            caption='🇺🇦 2.0 Как работает доставка.',
            reply_markup=GO_BACK_TO_OLX_UKRAINE_MENU())
    except Exception as e:
        print(e)

# 🇺🇦 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='olx_ukraine_email_inquiry')
async def olx_ukraine_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/4H0mhkl',
            caption='🇺🇦 Запрос почты.',
            reply_markup=GO_BACK_TO_OLX_UKRAINE_MENU())
    except Exception as e:
        print(e)

# 🇺🇦 Списание / баланс
@dp.callback_query_handler(lambda c: c. data=='olx_ukraine_write-off')
async def olx_ukraine_write_off(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/DpTVNNf',
            caption='🇺🇦 Списание / баланс.',
            reply_markup=GO_BACK_TO_OLX_UKRAINE_MENU())
    except Exception as e:
        print(e)

# 🇺🇦 Получить по ссылке
@dp.callback_query_handler(lambda c: c. data=='olx_ukraine_get_by_link')
async def olx_ukraine_get_by_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/mVgOKZ4',
            caption='🇺🇦 Получить по ссылке.',
            reply_markup=GO_BACK_TO_OLX_UKRAINE_MENU())
    except Exception as e:
        print(e)

# 🇺🇦 Возврат
@dp.callback_query_handler(lambda c: c. data=='olx_ukraine_return')
async def olx_ukraine_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/jbk5bwz',
            caption='🇺🇦 Возврат.',
            reply_markup=GO_BACK_TO_OLX_UKRAINE_MENU())
    except Exception as e:
        print(e)