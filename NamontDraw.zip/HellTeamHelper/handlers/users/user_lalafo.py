# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# ◀️ Назад (в 🇦🇿 Lalafo)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_lalafo_menu')
async def go_back_to_lalafo_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇦🇿 Lalafo.', reply_markup=LALAFO_MENU())

# 🇦🇿 Lalafo
@dp.callback_query_handler(lambda c: c.data=='lalafo')
async def lalafo(callback_query: types.CallbackQuery):
    try:
        await callback_query.message.edit_text('🇦🇿 Lalafo.', reply_markup=LALAFO_MENU())
    except Exception as e:
        print(e)

# 🇦🇿 Доставка курьером
@dp.callback_query_handler(lambda c: c. data=='lalafo_delivery')
async def lalafo_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/aHhRCrK',
            caption='🇦🇿 Доставка курьером.',
            reply_markup=GO_BACK_TO_LALAFO_MENU())
    except Exception as e:
        print(e)

# 🇦🇿 Как работает доставка
@dp.callback_query_handler(lambda c: c. data=='lalafo_how_delivery_works')
async def lalafo_how_delivery_works(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/oZniHrA',
            caption='🇦🇿 Как работает доставка.',
            reply_markup=GO_BACK_TO_LALAFO_MENU())
    except Exception as e:
        print(e)