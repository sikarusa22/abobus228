# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇧🇬 Включить 3D-S
@dp.callback_query_handler(lambda c: c. data=='olx_bulgaria_3d-s')
async def olx_bulgaria_3d_s(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/hj2vs9q',
            caption='🇧🇬 Включить 3D-S.',
            reply_markup=GO_BACK_TO_OLX_BULGARIA_MENU())
    except Exception as e:
        print(e)

# 🇧🇬 Доставка
@dp.callback_query_handler(lambda c: c. data=='olx_bulgaria_delivery')
async def olx_bulgaria_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/434mNsQ',
            caption='🇧🇬 Доставка.',
            reply_markup=GO_BACK_TO_OLX_BULGARIA_MENU())
    except Exception as e:
        print(e)

# 🇧🇬 Запрос почты
@dp.callback_query_handler(lambda c: c. data=='olx_bulgaria_ei')
async def olx_bulgaria_ei(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/LMdFEVr',
            caption='🇧🇬 Запрос почты.',
            reply_markup=GO_BACK_TO_OLX_BULGARIA_MENU())
    except Exception as e:
        print(e)