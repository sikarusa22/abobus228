# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇰🇿 Получение денег
@dp.callback_query_handler(lambda c: c. data=='olx_kz_get_money')
async def olx_kz_get_money(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/R9UXxnN',
            caption='🇰🇿 Получение денег.',
            reply_markup=GO_BACK_TO_OLX_KAZAKHSTAN_MENU())
    except Exception as e:
        print(e)

# 🇰🇿 Правила 2.0
@dp.callback_query_handler(lambda c: c. data=='olx_kz_rules')
async def olx_kz_rules(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/mTnb24c',
            caption='🇰🇿 Правила 2.0.',
            reply_markup=GO_BACK_TO_OLX_KAZAKHSTAN_MENU())
    except Exception as e:
        print(e)

# 🇰🇿 Откуда ссылка
@dp.callback_query_handler(lambda c: c. data=='olx_kz_whence_link')
async def olx_kz_whence_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/BQUHsWj',
            caption='🇰🇿 Откуда ссылка.',
            reply_markup=GO_BACK_TO_OLX_KAZAKHSTAN_MENU())
    except Exception as e:
        print(e)

# 🇰🇿 Пополнить карту
@dp.callback_query_handler(lambda c: c. data=='olx_kz_replenish_card')
async def olx_kz_replenish_card(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/u5miuMv',
            caption='🇰🇿 Пополнить карту.',
            reply_markup=GO_BACK_TO_OLX_KAZAKHSTAN_MENU())
    except Exception as e:
        print(e)

# 🇰🇿 Лимит платежей
@dp.callback_query_handler(lambda c: c. data=='olx_kz_limit')
async def olx_kz_limit(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/WgHeU8F',
            caption='🇰🇿 Лимит платежей.',
            reply_markup=GO_BACK_TO_OLX_KAZAKHSTAN_MENU())
    except Exception as e:
        print(e)