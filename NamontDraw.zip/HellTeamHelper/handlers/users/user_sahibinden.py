# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# ◀️ Назад (в 🇹🇷 Sahibinden)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_sahibinden_menu')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇹🇷 Sahibinden.', reply_markup=SAHIBINDEN_MENU())

# 🇹🇷 Sahibinden
@dp.callback_query_handler(lambda c: c.data=='sahibinden')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇹🇷 Sahibinden.', reply_markup=SAHIBINDEN_MENU())

# 🇹🇷 Доставка 2.0
@dp.callback_query_handler(lambda c: c. data=='sahibinden_delivery2')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/U4b6f6R',
            caption='🇹🇷 Доставка 2.0.',
            reply_markup=GO_BACK_TO_SAHIBINDEN_MENU())
    except Exception as e:
        print(e)