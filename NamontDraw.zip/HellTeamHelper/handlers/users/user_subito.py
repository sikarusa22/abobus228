# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇮🇹 Subito
@dp.callback_query_handler(lambda c: c. data=='subito_screenshots')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇮🇹 Subito', reply_markup=SUBITO_MENU())

# ◀️ Назад (в 🇮🇹 Subito)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_subito_screenshots_menu')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇮🇹 Subito', reply_markup=SUBITO_MENU())

# SCREENSHOTS: 🇮🇹 Subito

# 🇮🇹 Доставка 2.0
@dp.callback_query_handler(lambda c: c. data=='subito_delivery')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/vHG1qlU',
            caption='<b>Текущее меню:</b> 🇮🇹 Доставка 2.0.',
            reply_markup=GO_BACK_TO_SUBITO_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇮🇹 Ожидается оплата 1.0
@dp.callback_query_handler(lambda c: c. data=='subito_waiting_for_payment')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/LWWfAsR',
            caption='<b>Текущее меню:</b> 🇮🇹 Ожидается оплата 1.0.',
            reply_markup=GO_BACK_TO_SUBITO_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇮🇹 Товар оплачен 2.0
@dp.callback_query_handler(lambda c: c. data=='subito_item_paid')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/rGHQf7Y',
            caption='<b>Текущее меню:</b> 🇮🇹 Товар оплачен 2.0.',
            reply_markup=GO_BACK_TO_SUBITO_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇮🇹 PUSH уведомление
@dp.callback_query_handler(lambda c: c. data=='subito_push_notification')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/mCWk5qU',
            caption='<b>Текущее меню:</b> 🇮🇹 PUSH уведомление.',
            reply_markup=GO_BACK_TO_SUBITO_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇮🇹 Лимит
@dp.callback_query_handler(lambda c: c. data=='subito_limit')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/6BkupLJ',
            caption='<b>Текущее меню:</b> 🇮🇹 Лимит.',
            reply_markup=GO_BACK_TO_SUBITO_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)