# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# ◀️ Назад (в 🏢 Недвижка)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_realty_menu')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🏢 Недвижка.', reply_markup=REALTY_MENU())

# 🏢 Недвижка
@dp.callback_query_handler(lambda c: c.data=='realty_screenshots')
async def callback_proxy_again(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🏢 Недвижка.', reply_markup=REALTY_MENU())

# 🏬 Авито недвижка 2.0
@dp.callback_query_handler(lambda c: c. data=='realty_avito_realty_2_0')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/x4CSowC',
            caption='🏬 Авито недвижка 2.0.',
            reply_markup=GO_BACK_TO_REALTY_MENU())
    except Exception as e:
        print(e)

# 🏢 Циан 2.0
@dp.callback_query_handler(lambda c: c. data=='realty_cian_2_0')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)  
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/hbMbnKj',
            caption='🏢 Циан 2.0.',
            reply_markup=GO_BACK_TO_REALTY_MENU())
    except Exception as e:
        print(e)

# 👨‍⚖️ Циан 2.0: возврат (ТП)
@dp.callback_query_handler(lambda c: c. data=='realty_cian_2_0_return_tp')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/PCmpdZj',
            caption='👨‍⚖️ Циан 2.0: возврат (ТП).',
            reply_markup=GO_BACK_TO_REALTY_MENU())
    except Exception as e:
        print(e)

# 👨‍⚖️ Циан 2.0: возврат (ссылка)
@dp.callback_query_handler(lambda c: c. data=='realty_cian_2_0_return_link')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/RkQ4jFX',
            caption='👨‍⚖️ Циан 2.0: возврат (ссылка).',
            reply_markup=GO_BACK_TO_REALTY_MENU())
    except Exception as e:
        print(e)

# 💸 Циан 2.0: списание / баланс
@dp.callback_query_handler(lambda c: c. data=='realty_cian_2_0_write-off')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/T94n7ax',
            caption='💸 Циан 2.0: списание / баланс.',
            reply_markup=GO_BACK_TO_REALTY_MENU())
    except Exception as e:
        print(e)