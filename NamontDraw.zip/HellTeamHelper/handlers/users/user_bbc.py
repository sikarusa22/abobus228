# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# ◀️ Назад (в 🌀 BlaBlaCar)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_bbc_menu')
async def go_back_to_bbc_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🌀 BlaBlaCar.', reply_markup=BLABLACAR_MENU())

# 🌀 BlaBlaCar
@dp.callback_query_handler(lambda c: c.data=='bbc_screenshots')
async def bbc_screenshots(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🌀 BlaBlaCar.', reply_markup=BLABLACAR_MENU())

# 🌀 Поездка
@dp.callback_query_handler(lambda c: c. data=='bbc_delivery')
async def bbc_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

        media = types.MediaGroup()

        media.attach_photo('https://imgur.com/vQerddn')
        media.attach_photo('https://imgur.com/23CLkrq')

        await bot.send_media_group(callback_query.message.chat.id, media=media)
        await callback_query.message.answer(
            '🌀 Как проходит поездка.',
            reply_markup=GO_BACK_TO_BBC_MENU())
    except Exception as e:
        print(e)

# 🌀 Оплата онлайн
@dp.callback_query_handler(lambda c: c. data=='bbc_payment')
async def bbc_payment(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/BAFCD7o',
            caption='🌀 Оплата онлайн.',
            reply_markup=GO_BACK_TO_BBC_MENU())
    except Exception as e:
        print(e)

# 🌀 Возврат
@dp.callback_query_handler(lambda c: c. data=='bbc_return')
async def bbc_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/M2AQ0FF',
            caption='🌀 Возврат.',
            reply_markup=GO_BACK_TO_BBC_MENU())
    except Exception as e:
        print(e)