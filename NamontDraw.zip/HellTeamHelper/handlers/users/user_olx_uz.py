# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🇺🇿 Доставка
@dp.callback_query_handler(lambda c: c. data=='olx_uz_delivery')
async def olx_uz_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/LYUwbcu',
            caption='🇺🇿 Доставка.',
            reply_markup=GO_BACK_TO_OLX_UZBEKISTAN_MENU())
    except Exception as e:
        print(e)

# 🇺🇿 Отправить ссылку
@dp.callback_query_handler(lambda c: c. data=='olx_uz_send_link')
async def olx_uz_send_link(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/jJFJPqc',
            caption='🇺🇿 Отправить ссылку.',
            reply_markup=GO_BACK_TO_OLX_UZBEKISTAN_MENU())
    except Exception as e:
        print(e)

# 🇺🇿 Списание / баланс
@dp.callback_query_handler(lambda c: c. data=='olx_uz_write-off')
async def olx_uz_write_off(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/eqt3qYJ',
            caption='🇺🇿 Списание / баланс.',
            reply_markup=GO_BACK_TO_OLX_UZBEKISTAN_MENU())
    except Exception as e:
        print(e)

# 🇺🇿 Сменить карту
@dp.callback_query_handler(lambda c: c. data=='olx_uz_card')
async def olx_uz_card(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/12y2wUB',
            caption='🇺🇿 Сменить карту.',
            reply_markup=GO_BACK_TO_OLX_UZBEKISTAN_MENU())
    except Exception as e:
        print(e)

# 🇺🇿 Возврат
@dp.callback_query_handler(lambda c: c. data=='olx_uz_return')
async def olx_uz_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        file = 'C:/Users/desya/Desktop/Конечная версия бота/photos/olx/uzbekistan/return.jpg'
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/4XqN4h0',
            caption='🇺🇿 Возврат.',
            reply_markup=GO_BACK_TO_OLX_UZBEKISTAN_MENU())
    except Exception as e:
        print(e)