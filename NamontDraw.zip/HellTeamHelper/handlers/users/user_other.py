# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# SCREENSHOTS: 📞 WhatsApp

# 🎤 WhatsApp - микрофон
@dp.callback_query_handler(lambda c: c. data=='whatsapp_microphone')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/n5nvJ9R',
            caption='🎤 WhatsApp - микрофон.',
            reply_markup=GO_BACK_TO_OTHER_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 📷 WhatsApp - камера
@dp.callback_query_handler(lambda c: c. data=='whatsapp_camera')
async def callback_name(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/6SPSuLA',
            caption='📷 WhatsApp - камера.',
            reply_markup=GO_BACK_TO_OTHER_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)