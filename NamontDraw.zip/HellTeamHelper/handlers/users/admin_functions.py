# - *- coding: utf- 8 - *-
import asyncio

from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from filters import IsPrivate, IsAdmin
from keyboards.default import *
from keyboards.inline import *
from keyboards.inline.callback_datas import *
from loader import dp, bot
from states import StorageFunctions
from utils.db_api.sqlite import *

from aiogram.dispatcher.filters.state import State, StatesGroup

from time import sleep

from data.config import *

# Разбив сообщения на несколько, чтобы не прилетало ограничение от ТГ
def split_messages(get_list, count):
    return [get_list[i:i + count] for i in range(0, len(get_list), count)]

# Обработка инлайн кнопки "◀️ Назад (в админку)"
@dp.callback_query_handler(lambda c: c. data=='go_back_to_inline_adminka_menu', state="*")
async def go_back_to_inline_adminka_menu(callback_query: types.CallbackQuery, state: FSMContext):
    try:
        await state.finish()
        users_in_bot = get_ALL_usersx()
        await callback_query.message.edit_text(
            text=f"""
<b>🤖 Настройки бота</b>
└Пользователей: <code>{users_in_bot}</code>
            """,
            reply_markup=INLINE_ADMINKA())
    except Exception as e:
        print(e)

# Обработка инлайн кнопки "🔌 Статус"
@dp.callback_query_handler(lambda c: c. data=='bot_status')
async def bot_status(callback_query: types.CallbackQuery):
    current_bot_status = get_current_bot_status()
    await callback_query.message.edit_text(
        text=f'''
Текущий статус бота: {current_bot_status}
        ''',
        reply_markup=BOT_STATUS_MARKUP())

# Включение бота
@dp.callback_query_handler(lambda c: c. data=='set_bot_status_online')
async def set_bot_status_online(callback_query: types.CallbackQuery):
    try:
        current_bot_status = get_current_bot_status()
        update_settingsx(status="True")
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await callback_query.message.answer(
            text=f'''
Текущий статус бота: <code>{current_bot_status}</code>
            ''',
            reply_markup=BOT_STATUS_MARKUP())
    except Exception as e:
        print(e)

# Выключение бота
@dp.callback_query_handler(lambda c: c. data=='set_bot_status_offline')
async def set_bot_status_offline(callback_query: types.CallbackQuery):
    try:
        current_bot_status = get_current_bot_status()
        update_settingsx(status="False")
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await callback_query.message.answer(
            text=f'''
Текущий статус бота: <code>{current_bot_status}</code>
            ''',
            reply_markup=BOT_STATUS_MARKUP())
    except Exception as e:
        print(e)

# Обновление статуса бота
@dp.callback_query_handler(lambda c: c. data=='refresh_bot_status')
async def refresh_bot_status(callback_query: types.CallbackQuery):
    try:
        current_bot_status = get_current_bot_status()
        await callback_query.message.edit_text(
            text=f'''
Текущий статус бота: <code>{current_bot_status}</code>
            ''',
            reply_markup=BOT_STATUS_MARKUP())
    except Exception as e:
        print(e)

# Обработка инлайн кнопки "Поиск профиля"
@dp.callback_query_handler(lambda c: c. data=='find_user_profile')
async def find_user_profile(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>🧸 Введите логин или айди пользователя.</b>

Пример: <code>▶ 123456789 или @example</code>
        ''',
        reply_markup=GO_BACK_TO_INLINE_ADMINKA())
    await StorageFunctions.here_search_profile.set()

# Обработка инлайн кнопки "Рассылка"
@dp.callback_query_handler(lambda c: c. data=='make_advertisement')
async def make_advertisement(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('<b>Выберите тип рассылки.</b>', reply_markup=INLINE_CHOOSE_ADMINKA())

# Обработка кнопки "💬 Только текст"
@dp.callback_query_handler(lambda c: c. data=='advertisement_only_text')
async def advertisement__only_text(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>📢 Введите текст для рассылки.</b>
        ''',
        reply_markup=GO_BACK_TO_INLINE_ADMINKA())
    await StorageFunctions.only_text.set()

# Подтверждение отправки (только текст)
@dp.message_handler(state=StorageFunctions.only_text)
async def confirm_ad_only_text(message: Message, state: FSMContext):
    await state.update_data(caption=message.text)
    await bot.delete_message(message.chat.id, message.message_id)

    all_users_count_in_question = get_ALL_usersx()

    getter = await state.get_data()
    txt = getter["caption"]
    users_getted = 0
    users_failed = 0
    info = admin_message()

    await bot.send_message(
        chat_id=admins[0],
        text=f"""
📢 Вы хотите отправить текст ниже <code>{all_users_count_in_question}</code> пользователям ?

«{txt}»
        """,
        reply_markup=send_advertisement_only_text)

    await StorageFunctions.approve_only_text.set()

# Рассылка только текста
@dp.callback_query_handler(text="saot_yes_send_ad_photo_and_text", state=StorageFunctions.approve_only_text)
@dp.callback_query_handler(text="saot_not_send_kb", state=StorageFunctions.approve_only_text)
async def sends_ad_only_text(call: CallbackQuery, state: FSMContext):
    await bot.delete_message(call.message.chat.id, call.message.message_id)
    if call.data == "saot_not_send_kb":
        await state.finish()
        await bot.send_message(
            call.from_user.id,
            "<b>📢 Вы отменили отправку рассылки.</b>",
            reply_markup=CLOSE_BTN())
    if call.data == "saot_yes_send_ad_photo_and_text":
        getter = await state.get_data()
        txt = getter["caption"]
        users_getted = 0
        users_failed = 0
        info = admin_message()

        await bot.send_message(
            call.from_user.id,
            "📢 Рассылка началась...",
            reply_markup=CLOSE_BTN())

        for i in range(len(info)):
            try:
                sleep(1)
                users_getted += 1
                await bot.send_message(
                    chat_id=info[i],
                    text=str(txt),
                    reply_markup=RASSILKA_BUTTONS())
            except Exception as e:
                users_failed += 1
                print(e)

        await bot.send_message(
            call.from_user.id,
            f'''
<b>☑ Рассылка завершена.</b>

👤 Получивших сообщение: <code>{users_getted} юзеров</code> ✅
👤 Не получивших сообщение: <code>{users_failed} юзеров</code> ❌
            ''',
            reply_markup=CLOSE_BTN())
    await state.finish()

# Обработка кнопки "🌌 Фото и текст"
@dp.callback_query_handler(lambda c: c. data=='advertisement_photo_and_text')
async def advertisement_photo_and_text(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text(
        text='''
<b>📢 Отправьте ссылку на фото.</b>

<i>Получить можно в @photo_uploader_bot.</i>
        ''',
        reply_markup=GO_BACK_TO_INLINE_ADMINKA())
    await StorageFunctions.photo.set()

# Принятие текста для фото
@dp.message_handler(state=StorageFunctions.photo)
async def get_ad_photo(message: Message, state: FSMContext):
    await state.update_data(link=message.text)
    await bot.delete_message(message.chat.id, message.message_id)
    await message.answer("📢 Отправьте текст для рассылки пользователям.")
    await StorageFunctions.text.set()

# Подтверждение отправки (текст + фото)
@dp.message_handler(state=StorageFunctions.text)
async def confirm_ad(message: Message, state: FSMContext):
    await state.update_data(caption=message.text)
    await bot.delete_message(message.chat.id, message.message_id)

    all_users_count_in_question = get_ALL_usersx()

    getter = await state.get_data()
    photo = getter["link"]
    txt = getter["caption"]
    users_getted = 0
    users_failed = 0
    info = admin_message()

    await bot.send_photo(
        chat_id=admins[0],
        photo=photo,
        caption=f"""
📢 Вы хотите отправить это фото вместе с текстом ниже <code>{all_users_count_in_question}</code> пользователям ?

«{txt}»
        """,
        reply_markup=send_advertisement_photo_and_text)

    await StorageFunctions.approve.set()

# Рассылка фото с текстом
@dp.callback_query_handler(text="yes_send_ad_photo_and_text", state=StorageFunctions.approve)
@dp.callback_query_handler(text="not_send_kb", state=StorageFunctions.approve)
async def sends_ad_photo_and_text(call: CallbackQuery, state: FSMContext):
    await bot.delete_message(call.message.chat.id, call.message.message_id)
    if call.data == "not_send_kb":
        await state.finish()
        await bot.send_message(
            call.from_user.id,
            "<b>📢 Вы отменили отправку рассылки.</b>",
            reply_markup=CLOSE_BTN())
    if call.data == "yes_send_ad_photo_and_text":
        getter = await state.get_data()
        photo = getter["link"]
        txt = getter["caption"]
        users_getted = 0
        users_failed = 0
        info = admin_message()

        await bot.send_message(
            call.from_user.id,
            "📢 Рассылка началась...",
            reply_markup=CLOSE_BTN())

        for i in range(len(info)):
            try:
                sleep(1)
                users_getted += 1
                await bot.send_photo(
                    chat_id=info[i],
                    photo=photo,
                    caption=str(txt),
                    reply_markup=RASSILKA_BUTTONS())
            except Exception as e:
                users_failed += 1
                print(e)

        await bot.send_message(
            call.from_user.id,
            f'''
<b>☑ Рассылка завершена.</b>

👤 Получивших сообщение: <code>{users_getted} юзеров</code> ✅
👤 Не получивших сообщение: <code>{users_failed} юзеров</code> ❌
            ''',
            reply_markup=CLOSE_BTN())
    await state.finish()

# Принятие айди или логина для поиска профиля
@dp.message_handler(IsPrivate(), IsAdmin(), state=StorageFunctions.here_search_profile)
async def get_data_for_search_profile(message: types.Message, state: FSMContext):
    get_user_data = message.text
    if get_user_data.isdigit():
        get_user_id = get_userx(user_id=get_user_data)
    else:
        get_user_data = get_user_data[1:]
        get_user_id = get_userx(user_login=get_user_data.lower())
    if get_user_id is not None:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer(search_user_profile(get_user_id[1]), reply_markup=search_profile_func(get_user_id[1]))
        await state.finish()
    else:
        await bot.delete_message(message.chat.id, message.message_id)
        await message.answer(
            f'''
<b>❌ Профиль <code>{get_user_data}</code> не был найден.</b>

<b>🧸 Введите логин или айди пользователя.</b>

Пример: <code>▶ 123456789 или @example</code>
            ''',
            reply_markup=CLOSE_BTN())
        await StorageFunctions.here_search_profile.set()

# Отправка сообщения пользователю
@dp.callback_query_handler(user_send_message_cd.filter(), state="*")
async def send_user_to_message(call: CallbackQuery, callback_data: dict, state: FSMContext):
    async with state.proxy() as data:
        data["here_cache_user_id"] = callback_data.get("user_id")
    await bot.delete_message(call.message.chat.id, call.message.message_id)
    await bot.send_message(
        call.from_user.id,
        """
<b>💌 Введите сообщение для отправки</b>.
⚠ Сообщение будет сразу отправлено пользователю.
        """,
        reply_markup=CLOSE_BTN())
    await StorageFunctions.here_send_message.set()

# Уведомление об отправке сообщения пользователю
@dp.message_handler(IsPrivate(), IsAdmin(), state=StorageFunctions.here_send_message)
async def input_send_user_message(message: types.Message, state: FSMContext):
    get_message = f'''
<b>Вам сообщение:</b>

{message.text}'''
    async with state.proxy() as data:
        user_id = data["here_cache_user_id"]
    get_user = get_userx(user_id=user_id)
    await bot.send_message(user_id, get_message, reply_markup=CLOSE_BTN())
    await bot.delete_message(message.chat.id, message.message_id)

    await message.answer(
        f"""
<a href='tg://user?id={get_user[1]}'>{get_user[3]}</a> получил сообщение:

«{get_message}»
        """,
        reply_markup=CLOSE_BTN())
    await message.answer(search_user_profile(user_id), reply_markup=search_profile_func(user_id))
    await state.finish()