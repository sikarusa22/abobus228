# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# ◀️ Назад (в 🇲🇩 999)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_999_moldova_menu')
async def go_back_to_999_moldova_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇲🇩 999.', reply_markup=MOLDOVA_999_MENU())

# 🇲🇩 999
@dp.callback_query_handler(lambda c: c.data=='999_moldova')
async def _999_moldova(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇲🇩 999.', reply_markup=MOLDOVA_999_MENU())

# 🇲🇩 Курьерская доставка
@dp.callback_query_handler(lambda c: c. data=='moldova_999_delivery')
async def moldova_999_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/iz80OKH',
            caption='🇲🇩 Курьерская доставка.',
            reply_markup=GO_BACK_TO_MOLDOVA_999_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇲🇩 Онлайн оплата
@dp.callback_query_handler(lambda c: c. data=='moldova_999_online_payment')
async def moldova_999_online_payment(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/1VL6hgh',
            caption='🇲🇩 Онлайн оплата.',
            reply_markup=GO_BACK_TO_MOLDOVA_999_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇲🇩 Недостаточно средств
@dp.callback_query_handler(lambda c: c. data=='moldova_999_no_balance')
async def moldova_999_no_balance(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/kI3peo5',
            caption='🇲🇩 Недостаточно средств.',
            reply_markup=GO_BACK_TO_MOLDOVA_999_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)

# 🇲🇩 Заказ оформлен
@dp.callback_query_handler(lambda c: c. data=='moldova_999_order_is_processed')
async def moldova_999_order_is_processed(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/mSb6Nv1',
            caption='🇲🇩 Заказ оформлен.',
            reply_markup=GO_BACK_TO_MOLDOVA_999_SCREENSHOTS_MENU())
    except Exception as e:
        print(e)