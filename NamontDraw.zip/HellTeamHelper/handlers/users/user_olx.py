# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.types import CallbackQuery

from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot

# 🎣 OLX
@dp.callback_query_handler(lambda c: c. data=='olx_screenshots')
async def olx_screenshots(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🎣 OLX.', reply_markup=OLX_MENU())

# ◀️ Назад (в 🎣 OLX)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_olx_menu')
async def go_back_to_olx_menu(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🎣 OLX.', reply_markup=OLX_MENU())

# ◀️ Назад (в 🇧🇬 Болгария)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_bulgaria_menu')
async def go_back_to_olx_bulgaria_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇧🇬 Болгария.', reply_markup=OLX_BULGARIA_MENU())

# 🇧🇬 Болгария
@dp.callback_query_handler(lambda c: c.data=='olx_bulgaria')
async def olx_bulgaria(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇧🇬 Болгария.', reply_markup=OLX_BULGARIA_MENU())

# ◀️ Назад (в 🇰🇿 Казахстан)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_kazakhstan_menu')
async def go_back_to_olx_kazakhstan_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇰🇿 Казахстан.', reply_markup=OLX_KAZAKHSTAN_MENU())

# 🇰🇿 Казахстан
@dp.callback_query_handler(lambda c: c.data=='olx_kazakhstan')
async def olx_kazakhstan(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇰🇿 Казахстан.', reply_markup=OLX_KAZAKHSTAN_MENU())

# ◀️ Назад (в 🇵🇱 Польша)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_poland_menu')
async def go_back_to_olx_poland_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇵🇱 Польша.', reply_markup=OLX_POLAND_MENU())

# OLX 🇵🇱 Польша
@dp.callback_query_handler(lambda c: c.data=='olx_poland')
async def olx_poland(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇵🇱 Польша.', reply_markup=OLX_POLAND_MENU())

# ◀️ Назад (в 🇵🇹 Португалия)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_portugal_menu')
async def go_back_to_olx_portugal_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇵🇹 Португалия.', reply_markup=OLX_PORTUGAL_MENU())

# 🇵🇹 Португалия
@dp.callback_query_handler(lambda c: c.data=='olx_portugal')
async def olx_portugal(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇵🇹 Португалия.', reply_markup=OLX_PORTUGAL_MENU())

# ◀️ Назад (в 🇷🇴 Румуния)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_romania_menu')
async def go_back_to_olx_romania_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇷🇴 Румуния.', reply_markup=OLX_ROMANIA_MENU())

# 🇷🇴 Румуния
@dp.callback_query_handler(lambda c: c.data=='olx_romania')
async def olx_romania(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇷🇴 Румуния.', reply_markup=OLX_ROMANIA_MENU())

# ◀️ Назад (в 🇺🇦 Украина)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_ukraine_menu')
async def go_back_to_olx_ukraine_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇺🇦 Украина.', reply_markup=OLX_UKRAINE_MENU())

# OLX 🇺🇦 Украина
@dp.callback_query_handler(lambda c: c.data=='olx_ukraine')
async def olx_ukraine(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇺🇦 Украина.', reply_markup=OLX_UKRAINE_MENU())

# ◀️ Назад (в 🇺🇿 Узбекистан)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_olx_uzbekistan_menu')
async def go_back_to_olx_uzbekistan_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇺🇿 Узбекистан.', reply_markup=OLX_UZBEKISTAN_MENU())

# 🇺🇿 Узбекистан
@dp.callback_query_handler(lambda c: c.data=='olx_uzbekistan')
async def olx_uzbekistan(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇺🇿 Узбекистан.', reply_markup=OLX_UZBEKISTAN_MENU())

# 📞 WhatsApp
@dp.callback_query_handler(lambda c: c. data=='other_screenshots')
async def other_screenshots(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('📞 WhatsApp', reply_markup=OTHER_SCREENSHOTS_MENU())

# ◀️ Назад (в ♦️📞 WhatsApp)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_other_screenshots_menu')
async def go_back_to_other_screenshots_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('📞 WhatsApp', reply_markup=OTHER_SCREENSHOTS_MENU())