# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# ◀️ Назад (в 🇧🇾 Куфар)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_kufar_menu')
async def go_back_to_kufar_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇧🇾 Куфар.', reply_markup=KUFAR_MENU())

# 🇧🇾 Куфар
@dp.callback_query_handler(lambda c: c.data=='kufar_screenshots')
async def kufar_screenshots(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('🇧🇾 Куфар.', reply_markup=KUFAR_MENU())

# 🇧🇾 Куфар 2.0
@dp.callback_query_handler(lambda c: c. data=='kufar_2_0')
async def kufar_2_0(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/hNBwggB',
            caption='🇧🇾 Куфар 2.0.',
            reply_markup=GO_BACK_TO_KUFAR_MENU())
    except Exception as e:
        print(e)

# 🇧🇾 Куфар 2.0 — списание / баланс
@dp.callback_query_handler(lambda c: c. data=='kufar_2_0_balance')
async def kufar_2_0_balance(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/pj47xSH',
            caption='🇧🇾 Куфар 2.0 — списание / баланс.',
            reply_markup=GO_BACK_TO_KUFAR_MENU())
    except Exception as e:
        print(e)

# 🇧🇾 Заказ оформлен
@dp.callback_query_handler(lambda c: c. data=='kufar_processed')
async def kufar_processed(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/I9w7ZKX',
            caption='🇧🇾 Заказ оформлен.',
            reply_markup=GO_BACK_TO_KUFAR_MENU())
    except Exception as e:
        print(e)

# 🇧🇾 Куфар 1.0
@dp.callback_query_handler(lambda c: c. data=='kufar_1_0')
async def kufar_1_0(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/LnPHrOj',
            caption='🇧🇾 Куфар 1.0.',
            reply_markup=GO_BACK_TO_KUFAR_MENU())
    except Exception as e:
        print(e)