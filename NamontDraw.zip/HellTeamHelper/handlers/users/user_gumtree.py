# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# ◀️ Назад (в 🇬🇧 Gumtree)
@dp.callback_query_handler(lambda c: c.data=='go_back_to_gumtree_menu')
async def go_back_to_gumtree_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('🇬🇧 Gumtree.', reply_markup=GUMTREE_MENU())

# 🇬🇧 Gumtree
@dp.callback_query_handler(lambda c: c.data=='gumtree')
async def gumtree(callback_query: types.CallbackQuery):
    try:
        await callback_query.message.edit_text('🇬🇧 Gumtree.', reply_markup=GUMTREE_MENU())
    except Exception as e:
        print(e)

# 🇬🇧 Доставка
@dp.callback_query_handler(lambda c: c. data=='gumtree_delivery')
async def gumtree_delivery(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/aztXrAm',
            caption='🇬🇧 Доставка.',
            reply_markup=GO_BACK_TO_GUMTREE_MENU())
    except Exception as e:
        print(e)