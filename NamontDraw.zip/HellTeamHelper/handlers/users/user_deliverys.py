# - *- coding: utf- 8 - *-
from aiogram import *
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery

from data.config import admins
from filters import IsPrivate
from keyboards.default import *
from keyboards.inline import *
from loader import dp, bot
from utils.other_func import clear_firstname

# 📦 Доставка
@dp.callback_query_handler(lambda c: c. data=='delivery_sevices_screenshots')
async def delivery_sevices_screenshots(callback_query: types.CallbackQuery):
    await callback_query.message.edit_text('📦 Доставка', reply_markup=DS_MENU())

# ◀️ Назад (в 📦 Доставка)
@dp.callback_query_handler(lambda c: c. data=='go_back_to_ds_menu')
async def go_back_to_ds_menu(callback_query: types.CallbackQuery):
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
    await callback_query.message.answer('📦 Доставка', reply_markup=DS_MENU())

# SCREENSHOTS: 📦 Доставка

# 🚕 Яндекс 2.0
@dp.callback_query_handler(lambda c: c. data=='ds_yandex')
async def ds_yandex(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/TCm9Myl',
            caption='🚕 Яндекс 2.0.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚕 Яндекс: списание
@dp.callback_query_handler(lambda c: c. data=='ds_yandex_write-off')
async def ds_yandex_write_off(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/uy9eDnQ',
            caption='🚕 Яндекс: списание.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚐 Dostavista 2.0
@dp.callback_query_handler(lambda c: c. data=='ds_dostavista')
async def ds_dostavista(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/0ICCn2W',
            caption='🚐 Dostavista 2.0.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚎 Почта РФ
@dp.callback_query_handler(lambda c: c. data=='ds_mail_rf')
async def ds_mail_rf(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/I9xKnQm',
            caption='🚎 Почта РФ.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚎 Почта РФ 2.0: Email
@dp.callback_query_handler(lambda c: c. data=='ds_mail_rf_email_inquiry')
async def ds_mail_rf_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/92RcgPN',
            caption='🚎 Почта РФ 2.0: Email.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚚 Boxberry 1
@dp.callback_query_handler(lambda c: c. data=='ds_boxberry_1')
async def ds_boxberry_1(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/6kjHLZp',
            caption='🚚 Boxberry.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚗 Boxberry 2.0
@dp.callback_query_handler(lambda c: c. data=='ds_boxberry_2')
async def ds_boxberry_2(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/tP55MF5',
            caption='🚗 Boxberry 2.0.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚗 Boxberry 2.0: Email
@dp.callback_query_handler(lambda c: c. data=='ds_boxberry_2_email_inquiry')
async def ds_boxberry_2_email_inquiry(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/JUEWzrG',
            caption='🚗 Boxberry 2.0: Email.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚛 СДЭК 1
@dp.callback_query_handler(lambda c: c. data=='ds_sdek_1')
async def ds_sdek_1(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/2Ror8lB',
            caption='🚛 СДЭК.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🛺 СДЭК 2.0
@dp.callback_query_handler(lambda c: c. data=='ds_sdek_2')
async def ds_sdek_2(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/IguhbMc',
            caption='🛺 СДЭК 2.0.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🛺 СДЭК 2.0: списание
@dp.callback_query_handler(lambda c: c. data=='ds_sdek_2_write-off')
async def ds_sdek_2_write_off(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/3LCydwA',
            caption='🛺СДЭК 2.0: списание.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🛺 СДЭК 2.0: нет уведомления
@dp.callback_query_handler(lambda c: c. data=='ds_sdek_2_no_notification')
async def ds_sdek_2_no_notification(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/B4HAR9V',
            caption='🛺СДЭК 2.0: нет уведомления.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🛺 СДЭК 2.0: возврат
@dp.callback_query_handler(lambda c: c. data=='ds_sdek_2_return')
async def ds_sdek_2_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/dwOTJGn',
            caption='🛺СДЭК 2.0: возврат.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# 🚙 ПЭК 2.0
@dp.callback_query_handler(lambda c: c. data=='ds_pek_2')
async def ds_pek_2(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/yN6wyf3',
            caption='🚙 ПЭК 2.0.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)

# ↩️ DHL 2.0: возврат
@dp.callback_query_handler(lambda c: c. data=='ds_dhl_2_return')
async def ds_dhl_2_return(callback_query: types.CallbackQuery):
    try:
        await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)
        await bot.send_photo(
            callback_query.message.chat.id,
            photo='https://imgur.com/it6Mc0m',
            caption='↩️ DHL 2.0: возврат.',
            reply_markup=GO_BACK_TO_DS_MENU())
    except Exception as e:
        print(e)