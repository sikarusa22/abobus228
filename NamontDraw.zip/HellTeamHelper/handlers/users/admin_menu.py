# - *- coding: utf- 8 - *-
from aiogram import types
from aiogram.dispatcher import FSMContext

from filters import IsPrivate, IsAdmin
from keyboards.default import get_functions_func, admins
from keyboards.inline.admin_inline import INLINE_ADMINKA
from loader import dp, bot
from utils.db_api.sqlite import *

from keyboards.inline.user_func import CLOSE_BTN

# Разбив сообщения на несколько, чтобы не прилетало ограничение от ТГ
def split_messages(get_list, count):
    return [get_list[i:i + count] for i in range(0, len(get_list), count)]

# Обработка кнопки "⚡️Настройки"
@dp.message_handler(IsPrivate(), IsAdmin(), text="⚡️Настройки", state="*")
async def bot_settings(message: types.Message, state: FSMContext):
    await state.finish()
    await bot.delete_message(message.chat.id, message.message_id)
    users_in_bot = get_ALL_usersx()
    await message.answer(
        f"""
<b>⚡️Настройки бота</b>
└Пользователей: <code>{users_in_bot}</code>
        """,
        reply_markup=INLINE_ADMINKA())

# Получение и отправка БД админу в личку с ботом
@dp.message_handler(IsPrivate(), IsAdmin(), text="/backup", state="*")
async def send_backup(message: types.Message, state: FSMContext):
    await state.finish()
    await bot.delete_message(message.chat.id, message.message_id)
    for admin in admins:
        with open("data/botBD.sqlite", "rb") as doc:
            await bot.send_document(
                admin,
                doc,
                caption=f"<b>📦 Database backup.</b>\n🕜 <code>{datetime.datetime.today().replace(microsecond=0)}</code>",
                reply_markup=CLOSE_BTN())

# Получение и отправка логов админу в личку с ботом
@dp.message_handler(IsPrivate(), IsAdmin(), text="/logs", state="*")
async def send_logs(message: types.Message, state: FSMContext):
    await state.finish()
    await bot.delete_message(message.chat.id, message.message_id)
    
    for admin in admins:
        with open(
            'data/logs/ip_adresses.txt', 'rb') as doc:
            await bot.send_document(
                admin,
                doc,
                caption=f'''<b>Users logs: (IP-adresses).</b>\n🕜 <code>{datetime.datetime.today().replace(microsecond=0)}</code>''',
                reply_markup=CLOSE_BTN())
        with open(
            'data/logs/phones.txt', 'rb') as doc:
            await bot.send_document(
                admin,
                doc,
                caption=f'''<b>Users logs: phones.</b>\n🕜 <code>{datetime.datetime.today().replace(microsecond=0)}</code>''',
                reply_markup=CLOSE_BTN())
        with open(
            'data/logs/bins_ccs.txt', 'rb') as doc:
            await bot.send_document(
                admin,
                doc,
                caption=f'''<b>Users logs: checked bins / cc's.</b>\n🕜 <code>{datetime.datetime.today().replace(microsecond=0)}</code>''',
                reply_markup=CLOSE_BTN())