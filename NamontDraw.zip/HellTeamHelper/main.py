# - *- coding: utf- 8 - *-
import asyncio
from aiogram import executor
from handlers import dp
from utils.set_bot_commands import set_default_commands
from utils.db_api.sqlite import *
import filters
import middlewares
async def on_startup(dp):
    await set_default_commands(dp)
    print("Бот успешно запущен.\n")
if __name__ == "__main__":
    while True:
        try:
            filters.setup(dp)
            middlewares.setup(dp)
            executor.start_polling(dp, on_startup=on_startup)
        except Exception as e:
            print(e)
