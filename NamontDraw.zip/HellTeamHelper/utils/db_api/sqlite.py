# - *- coding: utf- 8 - *-
import datetime
import logging
import random
import sqlite3
import time

from data.config import *

def logger(statement):
    logging.basicConfig(
        level=logging.INFO,
        filename="logs.log",
        format=f"[Executing] [%(asctime)s] | [%(filename)s LINE:%(lineno)d] | {statement}",
        datefmt="%d-%b-%y %H:%M:%S")
    logging.info(statement)

def handle_silently(function):
    def wrapped(*args, **kwargs):
        result = None
        try:
            result = function(*args, **kwargs)
        except Exception as e:
            logger("{}({}, {}) failed with exception {}".format(
                function.__name__, repr(args[1]), repr(kwargs), repr(e)))
        return result

    return wrapped

####################################################################################################
###################################### ФОРМАТИРОВАНИЕ ЗАПРОСА ######################################

# Форматирование запроса с аргументами
def update_format_with_args(sql, parameters: dict):
    values = ", ".join([
        f"{item} = ?" for item in parameters
    ])
    sql = sql.replace("XXX", values)
    return sql, tuple(parameters.values())

# Форматирование запроса без аргументов
def get_format_args(sql, parameters: dict):
    sql += " AND ".join([
        f"{item} = ?" for item in parameters
    ])
    return sql, tuple(parameters.values())

####################################################################################################
########################################### ЗАПРОСЫ К БД ###########################################

# Добавление пользователя
def add_userx(user_id, user_login, user_name, reg_date, deanons, shorts, screenshots, generations):
    with sqlite3.connect(path_to_db) as db:
        db.execute("INSERT INTO storage_users "
                   "(user_id, user_login, user_name, reg_date, deanons, shorts, screenshots, generations) "
                   "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ",
                   [user_id, user_login, user_name, reg_date, deanons, shorts, screenshots, generations])
        db.commit()

# Изменение пользователя
def update_userx(user_id, **kwargs):
    with sqlite3.connect(path_to_db) as db:
        sql = f"UPDATE storage_users SET XXX WHERE user_id = {user_id}"
        sql, parameters = update_format_with_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()

# Удаление пользователя
def delete_userx(**kwargs):
    with sqlite3.connect(path_to_db) as db:
        sql = "DELETE FROM storage_users WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()

# Получение пользователя
def get_userx(**kwargs):
    with sqlite3.connect(path_to_db) as db:
        sql = "SELECT * FROM storage_users WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        get_response = db.execute(sql, parameters)
        get_response = get_response.fetchone()
    return get_response

# Получение пользователей для рассылки фото + текст
def admin_message():
    conn = sqlite3.connect(path_to_db, check_same_thread=False)
    conn.row_factory = lambda cursor, row: row[0]
    cursor = conn.cursor()
    row = cursor.execute(f'SELECT user_id FROM storage_users').fetchall()
    return row

# Получение пользователей
def get_usersx(**kwargs):
    with sqlite3.connect(path_to_db) as db:
        sql = "SELECT * FROM storage_users WHERE "
        sql, parameters = get_format_args(sql, kwargs)
        get_response = db.execute(sql, parameters).fetchall()
    return get_response

# Получение всех пользователей
def get_all_usersx():
    with sqlite3.connect(path_to_db) as db:
        get_response = db.execute("SELECT * FROM storage_users").fetchall()
    return get_response

# Получение количества пользователей в БД
def get_ALL_usersx():
    conn = sqlite3.connect(path_to_db)
    cursor = conn.cursor()
    row = cursor.execute(f'SELECT * FROM storage_users').fetchone()

    amount_user_all = 0

    while row is not None:
        amount_user_all += 1

        row = cursor.fetchone()

    msg = f"""<code>{amount_user_all}</code>"""

    return msg

# Получение настроек
def get_settingsx():
    with sqlite3.connect(path_to_db) as db:
        get_response = db.execute("SELECT * FROM storage_settings").fetchone()
    return get_response

# Обновление настроек
def update_settingsx(**kwargs):
    with sqlite3.connect(path_to_db) as db:
        sql = f"UPDATE storage_settings SET XXX "
        sql, parameters = update_format_with_args(sql, kwargs)
        db.execute(sql, parameters)
        db.commit()

# Получение текущего статуса бота
def get_current_bot_status():
    with sqlite3.connect(path_to_db) as db:
        get_response = db.execute("SELECT * FROM storage_settings").fetchone()
        msg = f"""<code>{get_response}.</code>"""
    return msg

# Создание всех таблиц для БД
def create_bdx():
    with sqlite3.connect(path_to_db) as db:
        
        # Создание БД с хранением данных пользователей
        check_sql = db.execute("PRAGMA table_info(storage_users)")
        check_sql = check_sql.fetchall()
        check_create_users = [c for c in check_sql]
        if len(check_create_users) == 7:
            print("БД найдена (1/2)\n")
        else:
            db.execute("CREATE TABLE storage_users("
                        "increment INTEGER PRIMARY KEY AUTOINCREMENT, "
                        "user_id INTEGER, user_login TEXT, user_name TEXT, "
                        "reg_date TIMESTAMP, "
                        "deanons INTEGER, "
                        "shorts INTEGER, screenshots INTEGER, generations INTEGER) ")
            print("БД не найдена (1/2) | Создаём...\n")

        # Создание БД с хранением настроек
        check_sql = db.execute("PRAGMA table_info(storage_settings)")
        check_sql = check_sql.fetchall()
        check_create_settings = [c for c in check_sql]
        if len(check_create_settings) == 6:
            print("БД найдена (2/2)\n")
        else:
            db.execute("CREATE TABLE storage_settings("
                       "status TEXT ) ")
            sql = "INSERT INTO storage_settings(" \
                  "status) " \
                  "VALUES (?)"
            now_unix = int(time.time())
            parameters = ("True", now_unix)
            db.execute(sql, parameters)
            print("БД не найдена (2/2) | Создаём...\n")
        db.commit()