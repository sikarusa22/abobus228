# - *- coding: utf- 8 - *-
import asyncio
import time

import requests
from aiogram import Dispatcher
import sqlite3

from data.config import admins
from loader import bot
from utils.db_api.sqlite import get_settingsx, update_settingsx

# Рассылка сообщения всем администраторам
async def send_all_admin(message, markup=None):
    if markup is None:
        for admin in admins:
            try:
                await bot.send_message(admin, message)
            except:
                pass
    else:
        for admin in admins:
            try:
                await bot.send_message(admin, message, reply_markup=markup)
            except:
                pass

# Очистка имени пользователя от тэгов
def clear_firstname(firstname):
    if "<" in firstname: firstname = firstname.replace("<", "*")
    if ">" in firstname: firstname = firstname.replace(">", "*")
    return firstname
