# - *- coding: utf- 8 - *-
from utils.db_api.sqlite import get_userx, get_all_usersx, get_ALL_usersx
from aiogram import types
from aiogram.types import *

import datetime
import logging
import random
import sqlite3
import time

from data.config import *

# Меню информации
def INFO_BTNS():
    markup = types.InlineKeyboardMarkup(row_width=1)

    markup.add(
        types.InlineKeyboardButton(text='📊 Статистика', callback_data='show_personal_statistic'),
        types.InlineKeyboardButton(text='🦋 Купить рекламу', url=admin_link),
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_main_menu'))
    return markup

def get_user_profile(user_id):
    get_user = get_userx(user_id=user_id)
    get_all_users = get_ALL_usersx()
    if get_user and get_all_users is not None:

        msg = f'''
<b>MamontDraw - Отрисовщик</b>
<b>🧸 Ваш профиль</b>
├Юзернейм: @{get_user[2]}
├Идентификатор: <code>{get_user[1]}</code>
└Регистрация: <code>{get_user[4]}</code>

<b>🤖 О боте</b>
└Администратор: @{admin_username}
        '''
        return msg
    else:
        return None

# Личная статистика юзера
def get_user_statistic(user_id):
    get_user = get_userx(user_id=user_id)
    get_all_users = get_ALL_usersx()
    
    if get_user and get_all_users is not None:
        msg = f'''
<b>MamontDraw - Отрисовщик</b>
<b>🧸 Ваш профиль</b>
├Юзернейм: @{get_user[2]}
├ID: <code>{get_user[1]}</code>
└Регистрация: <code>{get_user[4]}</code>

<b>📊 Ваша статистика</b>
├Пробивов: <code>{get_user[5]}</code>
├Сокращено ссылок: <code>{get_user[6]}</code>
├Сделано скриншотов: <code>{get_user[7]}</code>
└Генераций: <code>{get_user[8]}</code>

<b>🤖 О боте</b>
└Администратор: @{admin_username}
        '''
        return msg
    else:
        return None

def search_user_profile(user_id):
    get_status_user = get_userx(user_id=user_id)
    if get_status_user is not None:
        msg = f'''
<b>MamontDraw - Отрисовщик</b>
<b>🧸 Профиль</b>
├Имя: <code>{get_status_user[3]}</code>
├Юзернейм: @{get_status_user[2]}
├Идентификатор: <code>{get_status_user[1]}</code>
└Регистрация: <code>{get_status_user[4]}</code>

<b>📊 Статистика</b>
├Пробивов: <code>{get_status_user[5]}</code>
├Сокращено ссылок: <code>{get_status_user[6]}</code>
├Сделано скриншотов: <code>{get_status_user[7]}</code>
└Генераций: <code>{get_status_user[8]}</code>
        '''
        return msg
    else:
        return None