# - *- coding: utf- 8 - *-
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from keyboards.inline.callback_datas import *

# Поиск профиля
def search_profile_func(user_id):
    
    search_profile = InlineKeyboardMarkup()
    
    send_msg_kb = InlineKeyboardButton(
        text="💌 СМС",
        callback_data=user_send_message_cd.new(
        user_id=user_id))

    close_button = InlineKeyboardButton(
        text="🗑 Закрыть",
        callback_data='close_btn',
        user_id=user_id)

    search_profile.add(send_msg_kb)
    search_profile.add(close_button)
    return search_profile