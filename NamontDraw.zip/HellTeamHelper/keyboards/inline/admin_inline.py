# - *- coding: utf- 8 - *-
from aiogram import types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from data.config import *

# Рассылка только текст
sure_send_ad_inl = InlineKeyboardMarkup()

yes_send_kb = InlineKeyboardButton(text="☑️ Отправить", callback_data="yes_send_ad")
not_send_kb = InlineKeyboardButton(text="✖️ Отменить", callback_data="not_send_kb")

sure_send_ad_inl.add(yes_send_kb, not_send_kb)

# Рассылка текст + фото
send_advertisement_photo_and_text = InlineKeyboardMarkup()

sa_pat_yes_send_kb = InlineKeyboardButton(text="☑️ Отправить", callback_data="yes_send_ad_photo_and_text")
sa_pat_not_send_kb = InlineKeyboardButton(text="✖️ Отменить", callback_data="not_send_kb")

send_advertisement_photo_and_text.add(sa_pat_yes_send_kb, sa_pat_not_send_kb)

# Рассылка только текст
send_advertisement_only_text = InlineKeyboardMarkup()

saot_pat_yes_send_kb = InlineKeyboardButton(text="☑️ Отправить", callback_data="saot_yes_send_ad_photo_and_text")
saot_pat_not_send_kb = InlineKeyboardButton(text="✖️ Отменить", callback_data="saot_not_send_kb")

send_advertisement_only_text.add(saot_pat_yes_send_kb, saot_pat_not_send_kb)

def INLINE_ADMINKA():
    markup = InlineKeyboardMarkup()

    btn_status = InlineKeyboardButton(text='🔌 Статус', callback_data='bot_status')
    btn1 = InlineKeyboardButton(text='📢 Рассылка', callback_data='make_advertisement')
    btn2 = InlineKeyboardButton(text='🔍 Поиск профиля', callback_data='find_user_profile')
    btn_close = InlineKeyboardButton(text='🗑 Закрыть', callback_data='close_btn')

    markup.row(btn_status)
    markup.row(btn1, btn2)
    markup.row(btn_close)

    return markup

def INLINE_CHOOSE_ADMINKA():
    markup = InlineKeyboardMarkup()

    btn_only_text = InlineKeyboardButton(text='💬 Только текст', callback_data='advertisement_only_text')
    btn_mix = InlineKeyboardButton(text='🌌 Фото и текст', callback_data='advertisement_photo_and_text')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_inline_adminka_menu')

    markup.row(btn_only_text, btn_mix)
    markup.row(btn_back)

    return markup

# Статус меню бота
def BOT_STATUS_MARKUP():
    markup = InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🟢 Включить', callback_data='set_bot_status_online')
    btn2 = InlineKeyboardButton(text='🟥 Выключить', callback_data='set_bot_status_offline')
    btn3 = InlineKeyboardButton(text='🔄 Обновить', callback_data='refresh_bot_status')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_inline_adminka_menu')

    markup.row(btn1, btn2)
    markup.row(btn3)
    markup.row(btn_back)

    return markup

# Кнопки в рассылке для юзеров
def RASSILKA_BUTTONS():
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton(text='🦋 Купить рекламу', url=admin_link))
    return markup

def GO_BACK_TO_INLINE_ADMINKA():
    markup = InlineKeyboardMarkup()

    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_inline_adminka_menu')

    markup.row(btn_back)

    return markup