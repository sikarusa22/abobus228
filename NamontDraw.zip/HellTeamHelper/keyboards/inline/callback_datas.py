# - *- coding: utf- 8 - *-
from aiogram.utils.callback_data import CallbackData

user_send_message_cd=CallbackData("send_message", "user_id")