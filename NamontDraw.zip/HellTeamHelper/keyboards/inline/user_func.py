# - *- coding: utf- 8 - *-
from aiogram import types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from data.config import *

def MAIN_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🔖 Помощник', callback_data='helper')
    btn2 = InlineKeyboardButton(text='🛠 Инструменты', callback_data='instruments')
    btn3 = InlineKeyboardButton(text='ℹ️ Информация', callback_data='information')
    btn_close = InlineKeyboardButton(text='🗑 Закрыть', callback_data='close_btn')

    markup.row(btn1, btn2)
    markup.row(btn3)
    markup.row(btn_close)

    return markup

# 🗑 Закрыть
def CLOSE_BTN():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='🗑 Закрыть', callback_data='close_btn'))
    return markup

#
def CLOSE_AND_SHOW_INSTRUMENTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='close_nazad_btn'))
    return markup

# Отменить стейт, удалить сообщение и показать меню инструментов
def CANCEL_STATE_AND_SHOW_INSTRUMENTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='🗑 Закрыть', callback_data='cc_and_show_instruments_menu'))
    return markup

# 👩‍🏫 Помощник
def HELPER_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🌌 Cкриншоты', callback_data='helper_screens')
    btn2 = InlineKeyboardButton(text='🧾 Диалоги', callback_data='helper_dialogs')
    btn3 = InlineKeyboardButton(text='📃 Мануалы', callback_data='helper_manuals')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_main_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn_back)

    return markup

# 🛠 Инструменты
def INSTRUMENTS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🖌 Отрисовка', callback_data='writings')
    btn2 = InlineKeyboardButton(text='🔍 Пробив', callback_data='show_deanon_menu')
    btn3 = InlineKeyboardButton(text='💳 BIN чекер', callback_data='bin_checker')
    btn4 = InlineKeyboardButton(text='🔗 Сократитель', callback_data='short_url')
    btn5 = InlineKeyboardButton(text='🌌 Скриншотер', callback_data='make_site_screenshot')
    btn6 = InlineKeyboardButton(text='📨 Почта', callback_data='temp_mail')
    btn7 = InlineKeyboardButton(text='🎭 Фейк личность', callback_data='fake_person')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_main_menu')

    markup.row(btn1)
    markup.row(btn2, btn3, btn4)
    markup.row(btn5, btn6)
    markup.row(btn7)
    markup.row(btn_back)
    return markup

def WRITINGS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🐥 Киви: баланс', callback_data='qiwi_balance')
    btn2 = InlineKeyboardButton(text='🐥 Киви: перевод', callback_data='qiwi_transfer')
    btn3 = InlineKeyboardButton(text='🐥 Киви: получение (ПК)', callback_data='qiwi_receiving_on_pc')
    btn4 = InlineKeyboardButton(text='🇷🇺 Сбербанк: баланс', callback_data='sberbank_balance')
    btn5 = InlineKeyboardButton(text='🇷🇺 Сбербанк: перевод', callback_data='sberbank_transfer')
    btn6 = InlineKeyboardButton(text='🇺🇦 Монобанк: баланс', callback_data='monobank')
    btn7 = InlineKeyboardButton(text='🇺🇦 Спортбанк', callback_data='sportbank')
    btn8 = InlineKeyboardButton(text='👨‍🦳 Тинькофф: перевод', callback_data='tinkoff_transfer')
    btn9 = InlineKeyboardButton(text='👨‍🦳 Авито', callback_data='tinkoff_transfer_avito')
    btn10 = InlineKeyboardButton(text='👨‍🦳 Юла', callback_data='tinkoff_transfer_youla')
    btn11 = InlineKeyboardButton(text='🇧🇾 Куфар: перевод', callback_data='write_kufar')
    btn12 = InlineKeyboardButton(text='🇰🇿 Каспи: баланс', callback_data='write_kaspi')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_instruments_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn4, btn5)
    markup.row(btn6, btn7)
    markup.row(btn8)
    markup.row(btn9, btn10)
    markup.row(btn11, btn12)
    markup.row(btn_back)

    return markup

# 🕵️‍♂️ Пробив
def DEANON_MENU():
    markup = types.InlineKeyboardMarkup(row_width=2)
    markup.add(
        types.InlineKeyboardButton(text='🌐 По IP-адресу', callback_data='ip_info'),
        types.InlineKeyboardButton(text='📲 По телефону', callback_data='phone_info'),
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_instruments_menu'))
    return markup

def FAKE_PERSON_CHOISE_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇨🇳', callback_data='fake_person_cn')
    btn2 = InlineKeyboardButton(text='🇨🇿', callback_data='fake_person_cz')
    btn3 = InlineKeyboardButton(text='🇩🇰', callback_data='fake_person_dk')
    btn4 = InlineKeyboardButton(text='🇫🇮', callback_data='fake_person_fi')
    btn5 = InlineKeyboardButton(text='🇫🇷', callback_data='fake_person_fr')
    btn6 = InlineKeyboardButton(text='🇩🇪', callback_data='fake_person_de')
    btn7 = InlineKeyboardButton(text='🇮🇹', callback_data='fake_person_it')
    btn8 = InlineKeyboardButton(text='🇯🇵', callback_data='fake_person_jp')
    btn9 = InlineKeyboardButton(text='🇯🇴', callback_data='fake_person_jo')
    btn10 = InlineKeyboardButton(text='🇰🇿', callback_data='fake_person_kz')
    btn11 = InlineKeyboardButton(text='🇱🇻', callback_data='fake_person_lv')
    btn12 = InlineKeyboardButton(text='🇲🇩', callback_data='fake_person_md')
    btn13 = InlineKeyboardButton(text='🇳🇱', callback_data='fake_person_nl')
    btn14 = InlineKeyboardButton(text='🇵🇱', callback_data='fake_person_pl')
    btn15 = InlineKeyboardButton(text='🇷🇺', callback_data='fake_person_ru')
    btn16 = InlineKeyboardButton(text='🇪🇸', callback_data='fake_person_sp')
    btn17 = InlineKeyboardButton(text='🇸🇪', callback_data='fake_person_se')
    btn18 = InlineKeyboardButton(text='🇺🇦', callback_data='fake_person_ua')
    btn19 = InlineKeyboardButton(text='🇬🇧', callback_data='fake_person_uk')
    btn20 = InlineKeyboardButton(text='🇺🇸', callback_data='fake_person_us')

    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_instruments_menu')

    markup.row(btn1, btn2, btn3, btn4, btn5)
    markup.row(btn6, btn7, btn8, btn9, btn10)
    markup.row(btn11, btn12, btn13, btn14, btn15)
    markup.row(btn16, btn17, btn18, btn19, btn20)
    markup.row(btn_back)

    return markup

# 🧾 Диалоги 🧾
def DIALOGS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='👋 Приветствие', callback_data='dialogs_welcome')
    btn2 = InlineKeyboardButton(text='📦 Сказать о доставке', callback_data='dialogs_tell_about_delivery')
    btn3 = InlineKeyboardButton(text='❔Вопросы о товаре', callback_data='dialogs_question_about_delivery')
    btn4 = InlineKeyboardButton(text='❓Другие вопросы', callback_data='dialogs_other_questions')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_helper_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3, btn4)
    markup.row(btn_back)

    return markup

# 📃 Мануалы 📃
def MANUALS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🐘 Скам', callback_data='manuals_scam')
    btn2 = InlineKeyboardButton(text='💳 Кардинг', callback_data='manuals_carding')
    btn3 = InlineKeyboardButton(text='🕳 Анонимность', callback_data='manuals_anonymity')
    btn4 = InlineKeyboardButton(text='📘 Прочее', callback_data='manuals_other_things')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_helper_menu')

    markup.row(btn1, btn2)
    markup.row(btn3)
    markup.row(btn4)
    markup.row(btn_back)

    return markup

#🐘 Скам
def SCAM_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='2.0 > 1.0', callback_data='two_better_than_one')
    btn2 = InlineKeyboardButton(text='Ошибки', callback_data='novice_errors')
    btn3 = InlineKeyboardButton(text='Общение', url='https://telegra.ph/Obshchenie-s-mamontom-07-12')
    btn4 = InlineKeyboardButton(text='Советы', url='https://telegra.ph/Lichnyj-primer-i-sovety-07-12')
    btn5 = InlineKeyboardButton(text='Основы СИ', url='https://telegra.ph/Osnovy-07-15')
    btn6 = InlineKeyboardButton(text='Работа с нуля', url='https://telegra.ph/Razbor-polnogo-skama-s-nulya-07-12')
    btn7 = InlineKeyboardButton(text='Портрет покупателя', url='https://telegra.ph/CHto-luchshe-vystavlyat-na-prodazhu-07-28')
    btn8 = InlineKeyboardButton(text='Лимиты', callback_data='mammoth_limits')
    btn9 = InlineKeyboardButton(text='Пополнение', url='https://telegra.ph/Manual-po-popolneniyu-07-12')
    btn10 = InlineKeyboardButton(text='Казино скам', url='https://telegra.ph/Manual-po-kazino-skamu-07-12')
    btn11 = InlineKeyboardButton(text='Знакомства', url='https://telegra.ph/Manual-po-Mambe-tinder-i-tp-07-12')
    btn12 = InlineKeyboardButton(text='Вакансии', url='https://telegra.ph/Manual-po-vakansiyam-07-12')
    btn13= InlineKeyboardButton(text='Неликвид', url='https://telegra.ph/Prodazha-nelikvida-tovarov-07-12')
    btn14 = InlineKeyboardButton(text='Ав. / Юла 2.0', url='https://telegra.ph/Rabota-Avito-20--Youla-20-07-28')
    btn15 = InlineKeyboardButton(text='BlaBlaCar', url='https://telegra.ph/Vsyo-ob-BlaBlaCar-07-12')
    btn16 = InlineKeyboardButton(text='Aviasales', url='https://telegra.ph/AVIASALES-Novoe-napravlenie-skama-ili-kak-sdelat-600k-za-10-dnej-07-28')
    btn17 = InlineKeyboardButton(text='Ozon', url='https://telegra.ph/Kak-sdelat-na-200k-za-nedelyu-na-OZON-07-28')
    btn18 = InlineKeyboardButton(text='Vinted.de', url='https://telegra.ph/Manual-po-vintedde-07-28')
    btn19 = InlineKeyboardButton(text='Amazon: рефаунд', url='https://telegra.ph/Amazon-refund-2021-08-06')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_manuals_menu')

    markup.row(btn1, btn2, btn3)
    markup.row(btn4, btn5)
    markup.row(btn6, btn7)
    markup.row(btn8, btn9)
    markup.row(btn10, btn11, btn12, btn13)
    markup.row(btn14, btn15, btn16, btn17)
    markup.row(btn18, btn19)
    markup.row(btn_back)

    return markup

#💳 Кардинг
def CARDING_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='Начало', url='https://telegra.ph/Karding-obuchenie-telegramm-s-nulya-07-22')
    btn2 = InlineKeyboardButton(text='Словарь', url='https://telegra.ph/Slovar-kardera-07-22')
    btn3 = InlineKeyboardButton(text='Проблемы', url='https://telegra.ph/Karding---pochemu-ne-poluchaetsya-07-22')
    btn4 = InlineKeyboardButton(text='Система', url='https://telegra.ph/Nastrojka-sistemy-pod-vbiv-07-22-2')
    btn5 = InlineKeyboardButton(text='Направления', url='https://telegra.ph/Napravleniya-v-kardinge-07-23')
    btn6 = InlineKeyboardButton(text='Вещевуха', url='https://telegra.ph/Veshchevoj-karding-nachalo-ili-karding-obuchenie-07-22')
    btn7 = InlineKeyboardButton(text='Дропы и т.д.', url='https://telegra.ph/Dropy-posredy---tvoi-druzya-07-22')
    btn8 = InlineKeyboardButton(text='Платёги', url='https://telegra.ph/Merchanty-i-platyozhnoe-povedenie-07-22')
    btn9 = InlineKeyboardButton(text='Кража СС', url='https://telegra.ph/Sposoby-kardinga-Karding-obuchenie-07-22')
    btn10 = InlineKeyboardButton(text='Антифрод', url='https://telegra.ph/CHto-zhe-takoe-antifrod-sistemy-i-kak-oni-rabotayut-07-23')
    btn11 = InlineKeyboardButton(text='Стиллер', callback_data='carding_stealer')
    btn12 = InlineKeyboardButton(text='Выбор СС', url='https://telegra.ph/Kak-maksimalno-pravilno-vybrat-SS-07-26')
    btn13 = InlineKeyboardButton(text='Поиск мерчей', callback_data='find_out_merchants')
    btn14 = InlineKeyboardButton(text='Поиск шопов', url='https://telegra.ph/Poisk-shopov-po-stranam-07-14-2')
    btn15 = InlineKeyboardButton(text='Создаём NFC', url='https://telegra.ph/Manual-po-sozdaniyu-NFC-dlya-realnogo-kardinga-07-23')
    btn16 = InlineKeyboardButton(text='Наш мерч', url='https://telegra.ph/Manual-po-polnomu-podnyatiyu-mercha-s-oplatoj-po-paypal-podojdet-dlya-obnala-logov-i-prochej-hujni-07-22')
    btn17 = InlineKeyboardButton(text='Ведём шоп', url='https://telegra.ph/Obuchenie-za-350-po-sozdaniyu-i-vedeniyu-vbivu-svoego-shopa-CHast-1-07-22')
    btn18 = InlineKeyboardButton(text='Рефаунд', url='https://telegra.ph/Bolshoj-manual-Refaund-ot-A-do-YA-Amazon-Asos-Apple-i-dr-07-27-2')
    btn19 = InlineKeyboardButton(text='Enroll', url='https://telegra.ph/Enroll--Reroll-07-28-2')
    btn20 = InlineKeyboardButton(text='Enroll: реализация', url='https://telegra.ph/Lekciya-po-realizacii-Enroll-07-27')
    btn21 = InlineKeyboardButton(text='Бины / банки', url='https://telegra.ph/Biny--Banki-07-28-2')
    btn22 = InlineKeyboardButton(text='Слив трафика ФБ', url='https://telegra.ph/Kuda-lit-trafik-v-Facebook-2021-12-07-28')
    btn23 = InlineKeyboardButton(text='Займ', url='https://telegra.ph/Oformlyaem-kreditzajm-na-full-info-07-26')
    btn24 = InlineKeyboardButton(text='Жизнь после', url='https://telegra.ph/Kak-izmenitsya-tvoya-zhizn-posle-kardinga-07-22')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_manuals_menu')

    markup.row(btn1, btn2, btn3)
    markup.row(btn4, btn5)
    markup.row(btn6, btn7, btn8, btn9)
    markup.row(btn10, btn11)
    markup.row(btn12, btn13, btn14)
    markup.row(btn15, btn16, btn17)
    markup.row(btn18, btn19, btn20)
    markup.row(btn21, btn22, btn23)
    markup.row(btn24)
    markup.row(btn_back)

    return markup

#🕵️‍♂️ Анонимность
def ANONYMITY_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🚓 Анонимность', url='https://telegra.ph/Manual-po-Anonimnosti-07-12')
    btn2 = InlineKeyboardButton(text='🔘 Работа в SPHERE', url='https://telegra.ph/Rabota-v-brauzere-Sphere-07-12')
    btn3 = InlineKeyboardButton(text='🤳 Работа с телефона', url='https://telegra.ph/Esli-budete-rabotat-s-telefona-07-12')
    btn4 = InlineKeyboardButton(text='🌐 Анон. роутер', url='https://telegra.ph/Delaem-anonimnyj-router-07-12')
    btn5 = InlineKeyboardButton(text='🌐 Фейк DNS', url='https://telegra.ph/Podmena-dns-na-routere-dlya-raboty-07-12')
    btn6 = InlineKeyboardButton(text='🌐 Свой VPN', url='https://telegra.ph/Podnimaem-svoj-VPN-07-27-3')
    btn7 = InlineKeyboardButton(text='🌐 Настройка Bitvise и Proxifier', url='https://telegra.ph/Anonimnaya-anonimnost-08-05')
    btn8 = InlineKeyboardButton(text='Ⓜ️ Лучшая криптовалюта', url='https://telegra.ph/Populyarno-po-Monero-07-28')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_manuals_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn4, btn5, btn6)
    markup.row(btn7)
    markup.row(btn8)
    markup.row(btn_back)

    return markup

#📚 Прочее
def OTHER_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='♻️Чистим метаданные', url='https://telegra.ph/Kak-izbezhat-blokirovki-za-foto-07-12')
    btn2 = InlineKeyboardButton(text='🎙Отправляем аудио ГС', url='https://telegra.ph/Otpravlyaem-audio-golosovym-soobshcheniem-07-12')
    btn3 = InlineKeyboardButton(text='🔉 Убираем спамблок', url='https://telegra.ph/Manual-kak-ubrat-spamblok-07-26')
    btn4 = InlineKeyboardButton(text='💲Вывод с BTC Banker', url='https://telegra.ph/BTC-Banker-vyvod-sredstv-i-polzovanie-07-12')
    btn5 = InlineKeyboardButton(text='📲 Экстренный сброс', url='https://telegra.ph/EHkstrennoe-unichtozhenie-dannyh-s-telefona-07-26')
    btn6 = InlineKeyboardButton(text='🤖Установка бота на VPS', url='https://telegra.ph/Manual-po-ustanovke-Python-botov-na-Ubuntu-VPS-07-26')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_manuals_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn4)
    markup.row(btn5)
    markup.row(btn6)
    markup.row(btn_back)

    return markup

def SCREENSHOTS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇷🇺 Авито', callback_data='avito_screenshots')
    btn2 = InlineKeyboardButton(text='🇷🇺 Юла', callback_data='youla_screenshots')
    btn3 = InlineKeyboardButton(text='🌀 BlaBlaCar', callback_data='bbc_screenshots')
    btn4 = InlineKeyboardButton(text='🎣 OLX', callback_data='olx_screenshots')
    btn5 = InlineKeyboardButton(text='🇧🇾 Куфар', callback_data='kufar_screenshots')
    btn6 = InlineKeyboardButton(text='📦 Доставка', callback_data='delivery_sevices_screenshots')
    btn7 = InlineKeyboardButton(text='🏢 Недвижка', callback_data='realty_screenshots')
    btn8 = InlineKeyboardButton(text='🇮🇹 Subito', callback_data='subito_screenshots')
    btn9 = InlineKeyboardButton(text='🇲🇩 999', callback_data='999_moldova')
    btn10 = InlineKeyboardButton(text='🇹🇷 Sahibinden', callback_data='sahibinden')
    btn11 = InlineKeyboardButton(text='🇪🇸 Correos', callback_data='correos')
    btn12 = InlineKeyboardButton(text='🇦🇿 Lalafo', callback_data='lalafo')
    btn13 = InlineKeyboardButton(text='🇬🇧 Gumtree', callback_data='gumtree')
    btn_other = InlineKeyboardButton(text='📞 WhatsApp', callback_data='other_screenshots')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_helper_menu')

    markup.row(btn1, btn2)
    markup.row(btn3, btn4, btn5)
    markup.row(btn6, btn7)
    markup.row(btn8, btn9, btn10)
    markup.row(btn11, btn12, btn13)
    markup.row(btn_other)
    markup.row(btn_back)

    return markup

def AVITO_MENU():
    markup = markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇷🇺 2.0 — подозрительный домен', callback_data='two_suspicious_domen')
    btn2 = InlineKeyboardButton(text='🇷🇺 2.0 — Запрос почты', callback_data='two_email_inquiry')
    btn3 = InlineKeyboardButton(text='🇷🇺 3.0 — Запрос кода', callback_data='three_code_inquiry')
    btn4 = InlineKeyboardButton(text='🇷🇺 CVC код', callback_data='cvc_code')
    btn5 = InlineKeyboardButton(text='🇷🇺 Cписание / баланс', callback_data='write-off_or_balance')
    btn6 = InlineKeyboardButton(text='🇷🇺 Нету уведомления', callback_data='no_notification')
    btn7 = InlineKeyboardButton(text='🇷🇺 Авито — 900', callback_data='error_900')
    btn8 = InlineKeyboardButton(text='🇷🇺 Дост. (ссылка)', callback_data='delivery_link')
    btn9 = InlineKeyboardButton(text='🇷🇺 Дост. (SMS)', callback_data='delivery_sms')
    btn10 = InlineKeyboardButton(text='🇷🇺 Дост. (Email)', callback_data='delivery_email')
    btn11 = InlineKeyboardButton(text='🇷🇺 Email-инструкция', callback_data='order_is_processed_email')
    btn12 = InlineKeyboardButton(text='🇷🇺 По SMS/ссылке', callback_data='sms_or_link')
    btn13 = InlineKeyboardButton(text='🇷🇺 Получение денег', callback_data='money_receiving')
    btn14 = InlineKeyboardButton(text='🇷🇺 Возврат', callback_data='money_return')
    btn15 = InlineKeyboardButton(text='🇷🇺 Получить по ссылке', callback_data='get_by_link')
    btn16 = InlineKeyboardButton(text='🇷🇺 Блокирует/не грузит', callback_data='blocked_or_not_loading')
    btn17= InlineKeyboardButton(text='🇷🇺 Указан Связной', callback_data='svyaznoi')
    btn18 = InlineKeyboardButton(text='🇷🇺 Указан RGS-Bank', callback_data='rgs_bank')
    btn19 = InlineKeyboardButton(text='🇷🇺 SMS от Бaнкa', callback_data='moneyback')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3, btn4)
    markup.row(btn5, btn6)
    markup.row(btn7)
    markup.row(btn8, btn9, btn10)
    markup.row(btn11, btn12)
    markup.row(btn13, btn14)
    markup.row(btn15, btn16)
    markup.row(btn17, btn18)
    markup.row(btn19)
    markup.row(btn_back)

    return markup

def YOULA_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇷🇺 2.0 — подозрительный домен', callback_data='youla_two_domen')
    btn2 = InlineKeyboardButton(text='🇷🇺 2.0 — 900', callback_data='youla_two_900')
    btn3 = InlineKeyboardButton(text='🇷🇺 CVC код', callback_data='youla_cvc_code')
    btn4 = InlineKeyboardButton(text='🇷🇺 3.0 — код', callback_data='youla_three_code_inquiry')
    btn5 = InlineKeyboardButton(text='🇷🇺 Запрос почты', callback_data='youla_email_inquiry')
    btn6 = InlineKeyboardButton(text='🇷🇺 Нет уведомления', callback_data='youla_no_notification')
    btn7 = InlineKeyboardButton(text='🇷🇺 Получить по ссылке', callback_data='youla_get_by_link')
    btn8 = InlineKeyboardButton(text='🇷🇺 Возврат', callback_data='youla_return')
    btn9 = InlineKeyboardButton(text='🇷🇺 Доставка (ссылка)', callback_data='youla_delivery_link')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3, btn4, btn5)
    markup.row(btn7, btn8)
    markup.row(btn9)
    markup.row(btn_back)

    return markup

def BLABLACAR_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🌀 Оплата онлайн', callback_data='bbc_payment')
    btn2 = InlineKeyboardButton(text='🌀 Поездка', callback_data='bbc_delivery')
    btn3 = InlineKeyboardButton(text='🌀 Возврат', callback_data='bbc_return')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn_back)

    return markup

def OLX_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇺🇦 Украина', callback_data='olx_ukraine')
    btn2 = InlineKeyboardButton(text='🇵🇱 Польша', callback_data='olx_poland')
    btn3 = InlineKeyboardButton(text='🇰🇿 Казахстан', callback_data='olx_kazakhstan')
    btn4 = InlineKeyboardButton(text='🇺🇿 Узбекистан', callback_data='olx_uzbekistan')
    btn5 = InlineKeyboardButton(text='🇷🇴 Румуния', callback_data='olx_romania')
    btn6 = InlineKeyboardButton(text='🇧🇬 Болгария', callback_data='olx_bulgaria')
    btn7 = InlineKeyboardButton(text='🇵🇹 Португалия', callback_data='olx_portugal')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1, btn2, btn3)
    markup.row(btn4, btn5)
    markup.row(btn6, btn7)
    markup.row(btn_back)

    return markup

def OLX_UKRAINE_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇺🇦 1.0 Доставка', callback_data='olx_ukraine_one_delivery_work')
    btn2 = InlineKeyboardButton(text='🇺🇦 2.0 Доставка', callback_data='olx_ukraine_two_delivery_work')
    btn3 = InlineKeyboardButton(text='🇺🇦 Запрос почты', callback_data='olx_ukraine_email_inquiry')
    btn4 = InlineKeyboardButton(text='🇺🇦 Получить по ссылке', callback_data='olx_ukraine_get_by_link')
    btn5 = InlineKeyboardButton(text='🇺🇦 Списание / баланс', callback_data='olx_ukraine_write-off')
    btn6 = InlineKeyboardButton(text='🇺🇦 Возврат', callback_data='olx_ukraine_return')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1, btn2)
    markup.row(btn3)
    markup.row(btn4)
    markup.row(btn5, btn6)
    markup.row(btn_back)

    return markup

def OLX_POLAND_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇵🇱 Запрос почты', callback_data='olx_poland_email_inquiry')
    btn2 = InlineKeyboardButton(text='🇵🇱 Доставка', callback_data='olx_poland_delivery')
    btn3 = InlineKeyboardButton(text='🇵🇱 Нет баланса', callback_data='olx_poland_no_balance')
    btn4 = InlineKeyboardButton(text='🇵🇱 Лимит на карте', callback_data='olx_poland_card_limit')
    btn5 = InlineKeyboardButton(text='🇵🇱 Сообщить ссылку', callback_data='olx_poland_show_link')
    btn6 = InlineKeyboardButton(text='🇵🇱 Товар оплачен', callback_data='olx_poland_item_paid')
    btn7 = InlineKeyboardButton(text='🇵🇱 Нужно подтверждение', callback_data='olx_poland_need_verify')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3, btn4)
    markup.row(btn5)
    markup.row(btn6, btn7)
    markup.row(btn_back)

    return markup

def OLX_KAZAKHSTAN_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇰🇿 Правила 2.0', callback_data='olx_kz_rules')
    btn2 = InlineKeyboardButton(text='🇰🇿 Откуда ссылка', callback_data='olx_kz_whence_link')
    btn3 = InlineKeyboardButton(text='🇰🇿 Получение денег', callback_data='olx_kz_get_money')
    btn4 = InlineKeyboardButton(text='🇰🇿 Пополнить карту', callback_data='olx_kz_replenish_card')
    btn5 = InlineKeyboardButton(text='🇰🇿 Лимит платежей', callback_data='olx_kz_limit')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3)
    markup.row(btn4, btn5)
    markup.row(btn_back)

    return markup

def OLX_UZBEKISTAN_MENU():

    markup = types.InlineKeyboardMarkup()
    btn1 = InlineKeyboardButton(text='🇺🇿 Доставка', callback_data='olx_uz_delivery')
    btn2 = InlineKeyboardButton(text='🇺🇿 Отправить ссылку', callback_data='olx_uz_send_link')
    btn3 = InlineKeyboardButton(text='🇺🇿 Списание / баланс', callback_data='olx_uz_write-off')
    btn4 = InlineKeyboardButton(text='🇺🇿 Возврат', callback_data='olx_uz_return')
    btn5 = InlineKeyboardButton(text='🇺🇿 Сменить карту', callback_data='olx_uz_card')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3, btn5)
    markup.row()
    markup.row()
    markup.row()
    markup.row(btn_back)

    return markup

def OLX_ROMANIA_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇷🇴 Правила 2.0', callback_data='olx_ro_rules_2')
    btn2 = InlineKeyboardButton(text='🇷🇴 Запрос почты', callback_data='olx_ro_email_inquiry')
    btn3 = InlineKeyboardButton(text='🇷🇴 Откуда ссылка', callback_data='olx_ro_whence_link')
    btn4 = InlineKeyboardButton(text='🇷🇴 Пополнить', callback_data='olx_ro_replenish_by_300')
    btn5 = InlineKeyboardButton(text='🇷🇴 Товар оплачен', callback_data='olx_ro_item_paid')
    btn6 = InlineKeyboardButton(text='🇷🇴 Лимит на карте', callback_data='olx_ro_card_limit')
    btn7 = InlineKeyboardButton(text='🇷🇴 Включить 3D-S', callback_data='olx_ro_3d-s')
    btn8 = InlineKeyboardButton(text='🇷🇴 Подтверждение', callback_data='olx_ro_need_verify')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3)
    markup.row(btn4, btn5)
    markup.row(btn6, btn7)
    markup.row(btn8)
    markup.row(btn_back)

    return markup

def OLX_BULGARIA_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇧🇬 Доставка', callback_data='olx_bulgaria_delivery')
    btn2 = InlineKeyboardButton(text='🇧🇬 Запрос почты', callback_data='olx_bulgaria_ei')
    btn3 = InlineKeyboardButton(text='🇧🇬 Включить 3D-S', callback_data='olx_bulgaria_3d-s')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn_back)

    return markup

def OLX_PORTUGAL_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇵🇹 Запрос почты', callback_data='olx_portugal_email_inquiry')
    btn2 = InlineKeyboardButton(text='🇵🇹 Лимит на карте', callback_data='olx_portugal_limit')
    btn3 = InlineKeyboardButton(text='🇵🇹 Push-уведомление', callback_data='olx_portugal_push')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3)
    markup.row(btn_back)

    return markup

def LALAFO_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇦🇿 Доставка курьером', callback_data='lalafo_delivery')
    btn2 = InlineKeyboardButton(text='🇦🇿 Как работает доставка', callback_data='lalafo_how_delivery_works')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn_back)

    return markup

def DS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🚎 Почта РФ', callback_data='ds_mail_rf')
    btn2 = InlineKeyboardButton(text='🚎 Почта РФ 2.0: Email', callback_data='ds_mail_rf_email_inquiry')
    btn3 = InlineKeyboardButton(text='🚕 Яндекс 2.0', callback_data='ds_yandex')
    btn4 = InlineKeyboardButton(text='🚕 Яндекс: списание', callback_data='ds_yandex_write-off')
    btn5 = InlineKeyboardButton(text='🚐 Dostavista 2.0', callback_data='ds_dostavista')
    btn6 = InlineKeyboardButton(text='🚚 Boxberry', callback_data='ds_boxberry_1')
    btn7 = InlineKeyboardButton(text='🚗 Boxberry 2.0', callback_data='ds_boxberry_2')
    btn8 = InlineKeyboardButton(text='🚗 Boxberry 2.0: Email', callback_data='ds_boxberry_2_email_inquiry')
    btn9 = InlineKeyboardButton(text='🚛 СДЭК', callback_data='ds_sdek_1')
    btn10 = InlineKeyboardButton(text='🛺 СДЭК 2.0', callback_data='ds_sdek_2')
    btn11 = InlineKeyboardButton(text='🛺СДЭК 2.0: списание', callback_data='ds_sdek_2_write-off')
    btn14 = InlineKeyboardButton(text='🛺СДЭК 2.0: нет уведомления', callback_data='ds_sdek_2_no_notification')
    btn15 = InlineKeyboardButton(text='🛺СДЭК 2.0: возврат', callback_data='ds_sdek_2_return')
    btn12 = InlineKeyboardButton(text='🚙 ПЭК 2.0', callback_data='ds_pek_2')
    btn13 = InlineKeyboardButton(text='↩️ DHL 2.0: возврат', callback_data='ds_dhl_2_return')

    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1, btn2)
    markup.row(btn3, btn4)
    markup.row(btn5)
    markup.row(btn6, btn9)
    markup.row(btn7, btn10)
    markup.row(btn8, btn11)
    markup.row(btn12, btn14)
    markup.row(btn13, btn15)
    markup.row(btn_back)

    return markup

def REALTY_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🏬 Авито недвижка 2.0', callback_data='realty_avito_realty_2_0')
    btn2 = InlineKeyboardButton(text='🏢 Циан 2.0', callback_data='realty_cian_2_0')
    btn3 = InlineKeyboardButton(text='👨‍⚖️ Циан 2.0: возврат (ТП)', callback_data='realty_cian_2_0_return_tp')
    btn4 = InlineKeyboardButton(text='👨‍⚖️ Циан 2.0: возврат (ссылка)', callback_data='realty_cian_2_0_return_link')
    btn5 = InlineKeyboardButton(text='💸 Циан 2.0: списание / баланс', callback_data='realty_cian_2_0_write-off')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1, btn2)
    markup.row(btn3)
    markup.row(btn4)
    markup.row(btn5)
    markup.row(btn_back)

    return markup

def KUFAR_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇧🇾 Куфар 1.0', callback_data='kufar_1_0')
    btn2 = InlineKeyboardButton(text='🇧🇾 Куфар 2.0', callback_data='kufar_2_0')
    btn3 = InlineKeyboardButton(text='🇧🇾 Куфар 2.0 — списание / баланс', callback_data='kufar_2_0_balance')
    btn4 = InlineKeyboardButton(text='🇧🇾 Заказ оформлен', callback_data='kufar_processed')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1, btn2)
    markup.row(btn3)
    markup.row(btn4)
    markup.row(btn_back)

    return markup

def SUBITO_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇮🇹 Ожидается оплата 1.0', callback_data='subito_waiting_for_payment')
    btn2 = InlineKeyboardButton(text='🇮🇹 Доставка 2.0', callback_data='subito_delivery')
    btn3 = InlineKeyboardButton(text='🇮🇹 Товар оплачен 2.0', callback_data='subito_item_paid')
    btn4 = InlineKeyboardButton(text='🇮🇹 PUSH уведомление', callback_data='subito_push_notification')
    btn5 = InlineKeyboardButton(text='🇮🇹 Лимит', callback_data='subito_limit')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn4)
    markup.row(btn5)
    markup.row(btn_back)

    return markup

def MOLDOVA_999_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇲🇩 Курьерская доставка', callback_data='moldova_999_delivery')
    btn2 = InlineKeyboardButton(text='🇲🇩 Онлайн оплата', callback_data='moldova_999_online_payment')
    btn3 = InlineKeyboardButton(text='🇲🇩 Недостаточно средств', callback_data='moldova_999_no_balance')
    btn4 = InlineKeyboardButton(text='🇲🇩 Заказ оформлен', callback_data='moldova_999_order_is_processed')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2)
    markup.row(btn3, btn4)
    markup.row(btn_back)

    return markup

def SAHIBINDEN_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇹🇷 Доставка 2.0', callback_data='sahibinden_delivery2')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn_back)

    return markup

def CORREOS_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇪🇸 Доставка 2.0', callback_data='correos_delivery')
    btn2= InlineKeyboardButton(text='🇪🇸 PUSH уведомление', callback_data='correos_push')
    btn3= InlineKeyboardButton(text='🇪🇸 Пополнение', callback_data='correos_replenishment')
    btn4 = InlineKeyboardButton(text='🇪🇸 Возврат', callback_data='correos_return')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn2, btn3)
    markup.row(btn4)
    markup.row(btn_back)

    return markup

def GUMTREE_MENU():
    markup = types.InlineKeyboardMarkup()

    btn1 = InlineKeyboardButton(text='🇬🇧 Доставка', callback_data='gumtree_delivery')
    btn_back = InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu')

    markup.row(btn1)
    markup.row(btn_back)

    return markup

def OTHER_SCREENSHOTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='🎤 WhatsApp - микрофон', callback_data='whatsapp_microphone'),
        types.InlineKeyboardButton(text='📷 WhatsApp - камера', callback_data='whatsapp_camera'),
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_screenshots_menu'))
    return markup

def GO_BACK_TO_DIALOGS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_dialogs_menu'))
    return markup

def GO_BACK_TO_MANUALS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_manuals_menu'))
    return markup

def GO_BACK_TO_INSTRUMENTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_instruments_menu'))
    return markup

def GO_BACK_TO_INSTRUMENTS_MENU_FROM_PROXY_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='🔄 Заново', callback_data='get_proxy_again'),
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_instruments_menu'))
    return markup

def GO_BACK_TO_SCAM_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_scam_menu'))
    return markup

def GO_BACK_TO_CARDING_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_carding_menu'))
    return markup

def GO_BACK_TO_HELPER_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_helper_menu'))
    return markup

def GO_BACK_TO_ANONYMITY_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_anonymity_menu'))
    return markup

def GO_BACK_TO_OTHER_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_other_menu'))
    return markup

def GO_BACK_TO_AVITO_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_avito_menu'))
    return markup

def GO_BACK_TO_YOULA_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_youla_menu'))
    return markup

def GO_BACK_TO_DS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_ds_menu'))
    return markup

def GO_BACK_TO_OTHER_SCREENSHOTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_other_screenshots_menu'))
    return markup

def GO_BACK_TO_LALAFO_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_lalafo_menu'))
    return markup

def GO_BACK_TO_SUBITO_SCREENSHOTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_subito_screenshots_menu'))
    return markup

def GO_BACK_TO_MOLDOVA_999_SCREENSHOTS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_999_moldova_menu'))
    return markup

def GO_BACK_TO_OLX_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_menu'))
    return markup

def GO_BACK_TO_OLX_UKRAINE_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_ukraine_menu'))
    return markup

def GO_BACK_TO_OLX_POLAND_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_poland_menu'))
    return markup

def GO_BACK_TO_OLX_KAZAKHSTAN_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_kazakhstan_menu'))
    return markup

def GO_BACK_TO_OLX_ROMANIA_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_romania_menu'))
    return markup

def GO_BACK_TO_SAHIBINDEN_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_sahibinden_menu'))
    return markup

def GO_BACK_TO_CORREOS_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_correos_menu'))
    return markup

def GO_BACK_TO_GUMTREE_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_gumtree_menu'))
    return markup

def GO_BACK_TO_OLX_PORTUGAL_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_portugal_menu'))
    return markup

def GO_BACK_TO_OLX_BULGARIA_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_bulgaria_menu'))
    return markup

def GO_BACK_TO_OLX_UZBEKISTAN_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_olx_uzbekistan_menu'))
    return markup

def GO_BACK_TO_BBC_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_bbc_menu'))
    return markup

def GO_BACK_TO_KUFAR_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_kufar_menu'))
    return markup

def GO_BACK_TO_REALTY_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_realty_menu'))
    return markup

def GO_BACK_TO_INSTRUMENTS_MENU_FROM_BIN_CHECKER():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_instruments_menu_from_bin_checker'))
    return markup

def GO_BACK_TO_FAKE_PERSON_CHOISE_MENU_FROM_FAKE_PERSON():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_fake_person_choise_menu_from_fake_person'))
    return markup

def UNIVERSAL_GO_BACK_TO_MANUALS_MENU_FROM_CATEGORY():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='go_back_to_manuals_menu'))
    return markup

def ALTERNATIVE_GO_BACK_TO_SCAM_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='alternative_go_back_to_scam_menu'))
    return markup

def ALTERNATIVE_GO_BACK_TO_CARDING_MENU():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton(text='◀️ Назад', callback_data='alternative_go_back_to_carding_menu'))
    return markup
