# - *- coding: utf- 8 - *-
from aiogram.dispatcher.filters.state import State, StatesGroup

class StorageFunctions(StatesGroup):

    ### ЮЗЕР ФУНКЦИИ ###

    ## ИНСТРУМЕНТЫ ##
    here_deanon_ip = State() # Пробив IP
    here_deanon_phone = State() # Пробив телефона
    here_check_bin = State() # Чек BIN'а
    here_temp_mail = State() # Временная почта
    here_short_link = State() # Сократить ссылку
    here_make_screen = State() # Сделать скриншот
    
    ## ОТРИСОВКИ ##
    here_write_qiwi_balance = State() # Qiwi баланс
    here_write_qiwi_transfer = State() # Qiwi перевод
    here_write_qiwi_receiving_on_pc = State() # Qiwi получение на ПК
    here_write_sberbank_balance = State() # Сбер баланс
    here_write_sberbank_transfer = State() # Сбер перевод
    here_write_monobank = State() # Монобанк баланс
    here_write_sportbank = State() # Спортбанк баланс
    here_write_tinkoff = State() # Тинькофф баланс
    here_write_tinkoff_avito = State() # Тинькофф перевод Авито
    here_write_tinkoff_youla = State() # Тинькофф перевод Юла
    here_write_kufar = State() # Куфар перевод
    here_write_kaspi = State() # Каспи баланс

    ### АДМИН ФУНКЦИИ ###

    ## РАССЫЛКИ ##

    # ФОТО + ТЕКСТ #
    photo = State() # Принять фото для рассылки
    text = State() # Принять текст для рассылки
    approve = State() # Подтвердить рассылку

    # ТОЛЬКО ТЕКСТ #
    only_text = State() # Принять текст для рассылки
    approve_only_text = State() # Подтвердить рассылку

    ## ПОИСК ЮЗЕРА И CMC ##
    here_search_profile = State() # Поиск профиля
    here_cache_user_id = State() # Кеширование ID юзера
    here_send_message = State() # Отправить сообщение юзеру