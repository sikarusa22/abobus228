Чтобы начать работу нужно:
1. Установленный Python 3.7.X+
2. pip install -r requirments.txt находясь в директории с ботом
3. Заполнить конфиг settings.ini
4. Найти файл sqlite.py и запуститеньки егл
5. Запустить .bat для старта

Настройка конфига:
token=(токен от вашего бота)
admin_id=(id админа, получить в @getmyid_bot)
path_to_db=data/botBD.sqlite(по умолчанию, если переместил базу, то указать путь к ней)
admin_username=(никнейм админа без @)
admin_link=(https ссылка на аккаунт администратора)

Bot was developed by Screaze on Earth.

